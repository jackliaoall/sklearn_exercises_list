# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 16:10:30 2019

@author: lenovo
"""
########### 路径配置 ####################################    ******(必改)*****
out_path = r'D:\\我的文件\\龙源\\文件\\【附属部件】\\PYTHON_CODE\\LONGYUAN-V15.2'

########### 训练原始文件路径配置 #########################    ******(必改)*****
new_train_dir = 'TRAIN_HB'  # 注意“要短”
zip_train_path = out_path+'\\数据管理\\原始数据\\用于训练的原始数据\\'+new_train_dir

########### 预测原始文件路径配置 #########################    ******(必改)*****
new_predict_off_dir = 'PREDICT_OFF_HB'  # 注意“要短”
new_predict_on_dir = 'PREDICT_ON_HB'    # 注意“要短”
zip_predict_off_path = out_path+'\\数据管理\\原始数据\\离线测试的原始数据\\'+new_predict_off_dir
zip_predict_on_path = out_path+'\\数据管理\\原始数据\\在线测试的原始数据\\'+new_predict_on_dir

########### 共用文件路径配置 #############################    ******(无需修改)*****
machine_info_path = out_path+r'\\数据管理\\原始数据\\机组信息.xlsx' 
machine_path = out_path+r'\\数据管理\\原始数据\\附属部件故障记录.xlsx'

########### 训练集、测试集在数据库中的名称 ################    ******(无需修改)*****
create_table_name_train = 'DATA_'+new_train_dir
index_name_train = 'INDEX_'+new_train_dir

create_table_name_predict_off = 'DATA_'+new_predict_off_dir
index_name_predict_off = 'INDEX_'+new_predict_off_dir

create_table_name_predict_on = 'DATA_'+new_predict_on_dir
index_name_predict_on = 'INDEX_'+new_predict_on_dir

########### 训练集、测试集聚合后在数据库中的名称 ###########    ******(无需修改)*****
agg_table_name_train = 'DATA_'+new_train_dir+'_AGG'                   # 训练数据聚合
agg_index_name_train = 'INDEX_'+new_train_dir+'_AGG'

agg_table_name_predict_off = 'DATA_'+new_predict_off_dir+'_AGG'       # 离线测试数据聚合
agg_index_name_predict_off = 'INDEX_'+new_predict_off_dir+'_AGG'

agg_table_name_predict_on = 'DATA_'+new_predict_on_dir+'_AGG'         # 在线测试数据聚合
agg_index_name_predict_on = 'INDEX_'+new_predict_on_dir+'_AGG'

########### 进程数量 ######################################    ******(选改)*****
processes_num = 10

########### 数据准备（收集数据，聚合）的参数配置 ############    ******(无需修改)*****
param_prepare_create_train = {'create_table_name':create_table_name_train,'create_table_index_name':index_name_train,'zip_path':zip_train_path,'processes_num':processes_num,'time_column':'LocalTime',
'data_machineid_column':'风机ID','data_machinetype_column':'风机类型','data_machinelocation_column':'风场','data_starttime_column':'开始时间','data_endtime_column':'结束时间'}

param_prepare_create_predict_off = {'create_table_name':create_table_name_predict_off,'create_table_index_name':index_name_predict_off,'zip_path':zip_predict_off_path,'processes_num':processes_num,'time_column':'LocalTime',
'data_machineid_column':'风机ID','data_machinetype_column':'风机类型','data_machinelocation_column':'风场','data_starttime_column':'开始时间','data_endtime_column':'结束时间'}

param_prepare_create_predict_on = {'create_table_name':create_table_name_predict_on,'create_table_index_name':index_name_predict_on,'zip_path':zip_predict_on_path,'processes_num':processes_num,'time_column':'LocalTime',
'data_machineid_column':'风机ID','data_machinetype_column':'风机类型','data_machinelocation_column':'风场','data_starttime_column':'开始时间','data_endtime_column':'结束时间'}

param_prepare_agg_train = {'ora_table_name':create_table_name_train,'ora_agg_table_name':agg_table_name_train,'agg_table_index_name':agg_index_name_train,'processes_num':processes_num}
param_prepare_agg_predict_off = {'ora_table_name':create_table_name_predict_off,'ora_agg_table_name':agg_table_name_predict_off,'agg_table_index_name':agg_index_name_predict_off,'processes_num':processes_num}
param_prepare_agg_predict_on = {'ora_table_name':create_table_name_predict_on,'ora_agg_table_name':agg_table_name_predict_on,'agg_table_index_name':agg_index_name_predict_on,'processes_num':processes_num}

########### 数据准备（建模、预测）的参数配置 ################    ******(选改)*****
param_prepare_train = {'ora_table_name':agg_table_name_train,'time_column':'LOCALTIME','data_machineid_column':'风机ID','data_machinetype_column':'风机类型',
                       'data_machinelocation_column':'风场','data_starttime_column':'开始时间','data_endtime_column':'结束时间','fault_machineid_column':'风机ID',
                       'fault_machinelocation_column':'风场','fault_reason_column':'故障原因','fault_starttime_column':'故障开始时间','fault_endtime_column':'故障结束时间',
                       'fault_type_column':'故障类型','use_start':True,'data_all_days':60,'fault_days':30,'normal_startday':110,'normal_endday':180}

param_prepare_predict_off = {'ora_table_name':agg_table_name_predict_off,'time_cloumn':'LOCALTIME'}

param_prepare_predict_on = {'ora_table_name':agg_table_name_predict_on,'time_cloumn':'LOCALTIME'}

########### 风机场、机组型号配置(用于数据预处理) ##############  ******(更换机场时修改)*****
Machine_location_list = ['吉风','聚风','普发','迅风','麒麟山']                  # '吉风','聚风','普发','迅风','麒麟山'
Machine_version_list = ['UP70-1500','UP77-1500','UP82-1500','UP96-2000']       # 'UP70-1500','UP77-1500','UP82-1500','UP96-2000'

# =============================================================================
# -----------------------------------------------------------------------------
# =============================================================================

########### 数据准备时，设置机场、机型的筛选方式 ############## ******(选改)*****
Machine_location =  False                # Machine_location = True 表示选取同机场、同型号机组；Machine_location = False 表示选取不同机场、同型号机组；
Machine_version_UP =  False              # Machine_version_UP = True 表示选取机型时采用"UPYY-XXXX"; Machine_version_UP = False 表示选取机型时采用"XXXX"; 

########### 数据训练时，设置机场、机型 #######################  ******(选改)*****
Machine_location_name = '吉风'           # 当 Machine_location = True时 ，设置该选项
Machine_version_name = 'UP77-1500'       # 当 Machine_version_UP = True时，设置该选项
Machine_version_code = '1500'            # 当 Machine_version_UP = False时，设置该选项

########### 数据验证时，挑选故障类型、机组名 #################  ******(必改)*****
Fault_name_train = ['正常','冷却风扇电机损坏','温控阀失效','散热片堵塞']
Machine_name_test = ['吉风-1','吉风-89','吉风-43','吉风-55']

# =============================================================================
# -----------------------------------------------------------------------------
# =============================================================================

########### 输出结果分类方式 ############   ******(无需修改)*****
count_type = '多分类[正常_各类别故障]'              
# count_type = '二分类[正常_故障]'
# count_type = '二分类[温控阀失效_其他]'
# count_type = '二分类[散热片堵塞_其他]'
# count_type = '二分类[油泵电机损坏_其他]'
# count_type = '三分类[正常_温控阀失效_不能识别故障]'
# count_type = '三分类[正常_散热片堵塞_不能识别故障]'
# count_type = '三分类[正常_油泵电机损坏_不能识别故障]'
# count_type = '五分类[正常_温控阀失效_散热片堵塞_油泵电机损坏_不能识别故障]'

########### 输出模型 ###################    ******(固化模型时修改)*****    
# model_type = 'Logistic模型'
# model_type = 'SVM模型'
# model_type = '随机森林模型'
# model_type = '决策树模型'
# model_type = 'XGBoost模型'
# model_type = 'LightGBM模型'
model_type = '模型综合投票'

########### 输出模型 ###################     ******(无需修改)*****  
Fault_type_name = 'FAULT_TYPE'               # 故障分类方式
Fault_i = 5                                  # 故障方式代码，也是该字段的列序号
count_i = count_type
if count_i=='多分类[正常_各类别故障]':
    Fault_type_name = 'FAULT_TYPE'           # 选择分类方式
    Fault_i = 5
elif count_i=='二分类[正常_故障]' : 
    Fault_type_name = 'FAULT_TYPE_2CLASS'    # 选择分类方式
    Fault_i = 6 
elif count_i=='二分类[温控阀失效_其他]': 
    Fault_type_name = 'FAULT_TYPE_2CLASS_W'  # 选择分类方式
    Fault_i = 7
elif count_i=='二分类[散热片堵塞_其他]': 
    Fault_type_name = 'FAULT_TYPE_2CLASS_S'  # 选择分类方式
    Fault_i = 8 
elif count_i=='二分类[油泵电机损坏_其他]': 
    Fault_type_name = 'FAULT_TYPE_2CLASS_Y'  # 选择分类方式
    Fault_i = 9
elif count_i=='三分类[正常_温控阀失效_不能识别故障]': 
    Fault_type_name = 'FAULT_TYPE_3CLASS_W'  # 选择分类方式
    Fault_i = 10 
elif count_i=='三分类[正常_散热片堵塞_不能识别故障]': 
    Fault_type_name = 'FAULT_TYPE_3CLASS_S'  # 选择分类方式
    Fault_i = 11 
elif count_i=='三分类[正常_油泵电机损坏_不能识别故障]': 
    Fault_type_name = 'FAULT_TYPE_3CLASS_Y'  # 选择分类方式
    Fault_i = 12
elif count_i=='五分类[正常_温控阀失效_散热片堵塞_油泵电机损坏_不能识别故障]': 
    Fault_type_name = 'FAULT_TYPE_5CLASS'    # 选择分类方式
    Fault_i = 13
else: pass

######机组信息列名配置(选取使用的参数)####################     ******(无需修改)*****
data_columns_name = [
    '1#桨叶片角度(桨距角)','1#桨电机温度','2#桨叶片角度(桨距角)','2#桨电机温度','3#桨叶片角度(桨距角)','3#桨电机温度',
    'WGEN.GenSenMaxTmp','WGEN.TemGenStaU','WGEN.TemGenStaV','WNAC.AirDensity','WNAC.Atmospress','WNAC.ReadWindSpeed','WTRM.GBoxOilPmpP',
    'WTRM.TemGBoxOilE', 'WTUR.PCurveSts','主轴刹车液压 ','主轴承温度','偏航角度(扭缆角度）','功率因数','发电机无功功率','发电机有功功率',
    '发电机转速','发电机非驱动端轴承温度','发电机驱动端轴承温度','变桨控制柜1温度','变桨控制柜2温度','变桨控制柜3温度','变频器温度',
    '塔底控制柜温度','实际扭矩','扭矩设定值','无功发电量总计','无功用电量总计','有功发电量总计','有功用电量总计','机舱与风向夹角',
    '机舱侧向振动值','机舱控制柜温度','机舱角度（位置）','机舱轴向振动值','桨叶片角度(桨距角)','网侧L1相电压','网侧L1相电流','网侧L2相电压',
    '网侧L2相电流','网侧L3相电压', '网侧L3相电流' ,'网侧频率','舱内温度','舱外温度','轮毂内温度','风向','风轮转速','风速','齿轮箱油压',
    '齿轮箱油温','风机状态','齿轮箱高速轴非驱动端轴承温度','齿轮箱高速轴驱动端轴承温度','功率曲线状态']

##############数据列名中英文对应##########################    ******(无需修改)*****
data_columns_map = {
    'DeviceId':'deviceid','DeviceName':'devicename','SiteId':'siteid','SiteName':'sitename','Timestamp':'timestamp','LocalTime':'localtime','GenerationTime':'generationtime',
    '1#桨叶片角度(桨距角)':'blade1position','1#桨电机温度':'temb1mot','2#桨叶片角度(桨距角)':'blade2position',
    '2#桨电机温度':'temb2mot','3#桨叶片角度(桨距角)':'blade3position','3#桨电机温度':'temb3mot','WGEN.GenSenMaxTmp':'gensenmaxtmp',
    'WGEN.TemGenStaU':'temgenstau','WGEN.TemGenStaV':'temgenstav','WNAC.AirDensity':'airdensity','WNAC.Atmospress':'atmospress',
    'WNAC.ReadWindSpeed':'readwindspeed','WTRM.GBoxOilPmpP':'gboxoilpmpp', 'WTRM.TemGBoxOilE':'temgboxile','WTUR.PCurveSts':'pcurvests',
    '主轴刹车液压 ':'powerstoretrbs','主轴承温度':'trmtmpshfbrg','偏航角度(扭缆角度）':'totaltwist','功率因数':'coscon',
    '发电机无功功率':'genreactivepw', '发电机有功功率':'genactivepw','发电机转速':'genspd','发电机非驱动端轴承温度':'temgennonde',
    '发电机驱动端轴承温度':'temgendriend','变桨控制柜1温度':'temblade1inver','变桨控制柜2温度':'temblade2inver',
    '变桨控制柜3温度':'temblade3inver','变频器温度':'cnvtmp','塔底控制柜温度':'temtowercab','实际扭矩':'torque',
    '扭矩设定值':'torquesetpoint','无功发电量总计':'rpproduction','无功用电量总计':'rpconsumed','有功发电量总计':'approduction',
    '有功用电量总计':'apconsumed','机舱与风向夹角':'windvanedirection','机舱侧向振动值':'vibrationlfil','机舱控制柜温度':'temnacellecab',
    '机舱角度（位置）':'nacelleposition','机舱轴向振动值':'vibrationvfil','桨叶片角度(桨距角)':'bladeposition',
    '网侧L1相电压':'volconl1','网侧L1相电流':'curconl1','网侧L2相电压':'volconl2','网侧L2相电流':'curconl2','网侧L3相电压':'volconl3',
     '网侧L3相电流':'curconl3' ,'网侧频率':'gridfreq','舱内温度':'temnacelle','舱外温度':'temout','轮毂内温度':'temhub',
    '风向':'winddirection','风轮转速':'rotorspd','风速':'windspeed','齿轮箱油压':'gearboxdistri','齿轮箱油温':'temgeaoil',
    '风机状态':'wtgstate','齿轮箱高速轴非驱动端轴承温度':'temgeamsnd','齿轮箱高速轴驱动端轴承温度':'temgeamsde','功率曲线状态':'powercurvestate'}  

############## 数据指标定界（过滤异常值） ##############    ******(更换运行参数取值范围时需要修改)***** 
# 1、确认工作时的错误值（是不可能出现的值，不是最大、最小值）；
# 2、确认当风机不工作时的值(可以用0来填充的值)
data_range = {
    'COSCON_AVG': [-1,1],
    'GRIDFREQ_AVG': [45,52],
    'TORQUE_AVG': [0,110],
    'TORQUESETPOINT_AVG': [0,110],
    'GENACTIVEPW_AVG': [-100,3000],       # 吉风 1500千瓦 [-100,2000]； # 麒麟山三期 2000千瓦 [-100,3000] ; # 普发 2000千瓦 [-100,3000]
    'GENREACTIVEPW_AVG': [-200,500],
    'GENSPD_AVG': [0,2000],
    'TEMNACELLE_AVG': [-40,60],
    'TEMOUT_AVG': [-40,50],
    'WINDDIRECTION_AVG': [0,360],
    'WINDSPEED_AVG': [0,50],
    'BLADE1POSITION_AVG': [-1,90],        # 桨角1 --> 1#桨叶片角度(桨距角)
    'BLADE2POSITION_AVG': [-1,90],        # 桨角2 --> 2#桨叶片角度(桨距角)
    'BLADE3POSITION_AVG': [-1,90],        # 桨角3 --> 3#桨叶片角度(桨距角)
    'ROTORSPD_AVG': [0,20],               # 叶轮转速 -> 风轮转速:   吉风 [0,20] ； # 麒麟山三期 [0,30]  
    'TOTALTWIST_AVG': [-720,720],
    'WINDVANEDIRECTION_AVG': [-180,360],  # 吉风[0,360] ； # 麒麟山[-180,180]
    'TEMGEAOIL_AVG': [-10,85],
    'TEMGENNONDE_AVG': [-10,90],
    'TEMGENDRIEND_AVG': [-10,90],
    'TEMGEAMSDE_AVG': [-10,90],
    'TEMGEAMSND_AVG': [-10,90],
    'GEARBOXDISTRI_AVG': [0,20],          # -902
    'TRMTMPSHFBRG_AVG': [-10,70],
    'CURCONL1_AVG': [-20,2000],
    'CURCONL2_AVG': [-20,2000],
    'CURCONL3_AVG': [-20,2000],
    'VOLCONL1_AVG': [350,450],
    'VOLCONL2_AVG': [350,450],
    'VOLCONL3_AVG': [350,450],
    'VIBRATIONLFIL_AVG': [-0.2,0.2],
    'VIBRATIONVFIL_AVG': [-0.2,0.2],
    'TEMTOWERCAB_AVG': [-40,50],
    'POWERSTORETRBS_AVG': [0,180]
}