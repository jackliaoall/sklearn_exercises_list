# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 17:28:43 2019

@author: lenovo
"""

from c0_config_zlx import *
from c0_public_fun_zlx import *

temp_test_off_path_0 = '\\数据管理\\预处理好的数据\\离线测试数据\\'
temp_train_path_0 = '\\数据管理\\预处理好的数据\\训练数据\\'
temp_model_path_0 = '\\数据管理\\结果输出\\模型保存\\'
temp_out_path_0 = '\\数据管理\\结果输出\\成果输出\\'
temp_out_plot = '典型故障散点图'

# c3
temp_train_path = mkdir(out_path + temp_train_path_0 + new_train_dir)+'\\'              # 处理后的训练数据存放路径

# c4
temp_model_path = mkdir(out_path + temp_model_path_0 + new_train_dir)+'\\'
temp_model_path = mkdir(temp_model_path + count_type)                                   # 训练模型存放路径

temp_out_train_path = mkdir(out_path + temp_out_path_0 + new_train_dir)+'\\'
temp_out_train_path = mkdir(temp_out_train_path + count_type)                           # 训练数据验证输出路径
temp_out_train_plot_path = mkdir(temp_out_train_path + '\\' + temp_out_plot)

# c5
temp_test_off_path = mkdir(out_path + temp_test_off_path_0 + new_predict_off_dir)+'\\'  # 离线测试数据路径

# c6
temp_out_off_path = mkdir(out_path + temp_out_path_0 + new_predict_off_dir)+'\\'
temp_out_off_path = mkdir(temp_out_off_path + count_type)                               # 离线预警输出成果路径
temp_out_off_plot_path = mkdir(temp_out_off_path + '\\' + temp_out_plot)

temp_out_on_path = mkdir(out_path + temp_out_path_0 + new_predict_on_dir)+'\\'
temp_out_on_path = mkdir(temp_out_on_path + count_type)                                 # 在线预警输出成果路径
temp_out_on_plot_path = mkdir(temp_out_on_path + '\\' + temp_out_plot)