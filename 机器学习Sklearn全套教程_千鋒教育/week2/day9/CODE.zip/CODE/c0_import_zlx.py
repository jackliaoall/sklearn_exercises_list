# -*- coding: utf-8 -*-
"""
Created on Sun Jun 30 04:26:47 2019

@author: lenovo
"""

import os
import zipfile
import datetime
import time
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier  
from sklearn import metrics 
from sklearn.ensemble import VotingClassifier
from sklearn.externals import joblib
from xgboost.sklearn import XGBClassifier
from lightgbm import LGBMClassifier
from scipy import interpolate
from pandas import DataFrame,Series
from tqdm import tqdm
from numpy import nan
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn import preprocessing
from apscheduler.schedulers.blocking import BlockingScheduler
from datetime import datetime
from datetime import timedelta
import warnings  #过滤警告
warnings.filterwarnings("ignore")

import cx_Oracle
from multiprocessing import Pool,Manager                     # 多进程

import sys
import dateutil
import tsfresh.feature_extraction.feature_calculators as fc  # 特征选择： https://www.jianshu.com/p/de2f7d333b9f
import threading

import matplotlib.pyplot as plt
import matplotlib as mpl