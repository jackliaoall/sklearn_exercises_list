# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 10:40:23 2019

@author: lenovo
"""

from c0_import_zlx import *
from c0_config_zlx import *
from c0_public_fun_zlx import *
from c0_create_dir import *

# =============================================================================
# temp_model_path = '\\数据管理\\结果输出\\模型保存\\'
# temp_model_path = mkdir(out_path + temp_model_path + new_train_dir)+'\\'
# temp_model_path = mkdir(temp_model_path + count_type)
# 
# temp_out_path = '\\数据管理\\结果输出\\成果输出\\'
# temp_out_path = mkdir(out_path + temp_out_path + new_predict_off_dir)+'\\'
# temp_out_path = mkdir(temp_out_path + count_type)
# 
# temp_test_off_path = out_path +'\\数据管理\\预处理好的数据\\离线测试数据\\'+ new_predict_off_dir+'\\'
# =============================================================================

fixed_field_name_list = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME']
fixed_field_len = len(fixed_field_name_list)
   
######################### 缺失值处理 #############################

# =============================================================================
# def fun_predict_missing_value(data_x):
#     data_x = data_x.loc[data_x.iloc[:,len(fixed_field_name_list):].dropna(axis='index', how='all').index]       # 删除行，条件是整行的运行参数均为NaN
#     data_x = data_x.sort_values(by = ['MACHINE_NAME','LOCALTIME'])                                              # 排序:按机组名，时间分组排序
#     run_columns_name = list(set(data_x.columns.tolist())-set(fixed_field_name_list))                            # 运行参数字段名
#     #run_columns_name = list(set(data_x.columns.tolist()).difference(set(fixed_field_name_list)))               # 运行参数字段名
#     run_columns_name.sort()                                                                                     # 运行参数字段名排序
#     data_y = data_x[['MACHINE_NAME']+run_columns_name].groupby(['MACHINE_NAME']).fillna(method='pad').fillna(method='bfill')            # 分组填充（按机组名分组）
#     data_y = pd.concat([data_x[fixed_field_name_list],data_y[run_columns_name]],axis = 1)
#     return data_y.reset_index(drop = True)
# =============================================================================

def fun_predict_missing_value(data_x):
    data_y = data_x.sort_values(by=['MACHINE_NAME','LOCALTIME']).reset_index(drop = True)
    return data_y

######################### 标准化数据 #############################
    
def fun_predict_MaxMinNormalization(data_x):
    # 标化到[-1,1]
    max_abs_scaler = preprocessing.MaxAbsScaler()                           # 定义标化模型
    data_x_df = data_x[data_x.columns.values.tolist()[fixed_field_len:]]    # 提取训练数据
    max_abs_scaler.fit(data_x_df)                                           # 训练 max_abs_scaler
    DF_maxAbs = pd.DataFrame(columns = data_x.columns.values.tolist()[fixed_field_len:])    # 定义空的特征指标标化后数据框
    for Machine_version_i in data_x['MACHINE_VERSION'].drop_duplicates().tolist():          # 循环选择风机型号
        data_timp_values = max_abs_scaler.transform(data_x.groupby(['MACHINE_VERSION'])[data_x.columns.values.tolist()[fixed_field_len:]].get_group(Machine_version_i))  # 按风机型号分组标化
        data_timp_df = pd.DataFrame(data_timp_values, index = data_x[data_x['MACHINE_VERSION']==Machine_version_i].index.tolist(), columns = data_x.columns.values.tolist()[fixed_field_len:]) # 将标化值数组转换为数据框，保留data_x中的index
        DF_maxAbs = pd.concat([DF_maxAbs,data_timp_df],axis=0)              # 将多个分组标化数据合并为一个数据框
    y_data = pd.concat([data_x[fixed_field_name_list],DF_maxAbs],axis=1)    # 为分组标化数据对应到相应机组信息
    return y_data

######################### 转换为哑变量 #############################

# =============================================================================
# def fun_predict_get_dummies(data_x_field):                  # 生成哑变量
#     dummy_data_x=pd.get_dummies(data_x_field,prefix='KEY')
#     return dummy_data_x,dummy_data_x.shape[1]               # 返回哑变量及哑变量个数
# 
# # 将'MACHINE_VERSION'转换为哑变量，并返回带哑变量的全量数据集，及哑变量的数量
# def fun_predict_Data_get_dummies(data_x,dummies_name):
#     data_x_temp = data_x.iloc[:,0:fixed_field_len]
#     for Machine_version_i in dummies_name:
#         data_x_temp[Machine_version_i] = 0
#         data_x_temp.loc[data_x_temp['MACHINE_VERSION'] == Machine_version_i[fixed_field_len:],Machine_version_i] = 1
#     data_y_list = [pd.concat([data_x_temp,data_x.iloc[:,fixed_field_len:]],axis=1),len(dummies_name)]
#     return data_y_list                                      # data_y_list[0]：返回数据框；data_y_list[1]：机器型号哑变量个数
# =============================================================================

######################### 特征选择 #############################    
    
def fun_predict_Data_get_Classifier(data_x):                                                           # 特征选择
    field_name = data_x.columns.values.tolist()
    job_classifier_model = joblib.load(temp_model_path + '\\job_classifier_model.pkl')                  # 加载特征选择模型
    
    X_df = data_x[field_name[fixed_field_len:]]
    X_trees = job_classifier_model.transform(X_df)                                                     # 返回所选的特征

    print('>>>>>> 完成测试特征选择！')  
    print('>>>>>> 测试特征集向量：',X_trees.shape)
    X_trees_df = pd.DataFrame(X_trees)
    X_trees_df.columns = X_df.columns[job_classifier_model.get_support()]                              # 为特征字段填充字段名称
    print('>>>>>> 测试特征名称：',X_trees_df.columns.tolist()) 

    data_y = pd.concat([data_x[field_name[0:fixed_field_len]], X_trees_df], axis=1)                    # 在axis=1 时为横向拼接。

    return data_y

######################### 获取预测数据，并预处理 #############################

def fun_data_processing_predict():
    if Machine_location:   # 同机场、同型号
        if Machine_version_UP:
           # 按机场、机组型号拆分数据
           f_open = open(temp_test_off_path +'['+Machine_location_name+'_'+Machine_version_name+']_Data_DF_x.csv',encoding='utf_8_sig')
        else:
           # 按机场、机组型号后四位输出数据
           f_open = open(temp_test_off_path +'['+Machine_location_name+'_'+Machine_version_code+']_Data_DF_x.csv',encoding='utf_8_sig')
    else:  # 不同机场、同型号
        if Machine_version_UP:
           # 按机场、机组型号拆分数据
           f_open = open(temp_test_off_path +'['+Machine_version_name+']_Data_DF_x.csv',encoding='utf_8_sig')
        else:
           # 按机场、机组型号后四位输出数据
           f_open = open(temp_test_off_path +'['+Machine_version_code+']_Data_DF_x.csv',encoding='utf_8_sig')         

    print(">>>>>> 测试数据读取中，请等待...")
    data = pd.read_csv(f_open)  # 读应用数据
    
    # =============================================================================按机器名称占比拆分
    
    print("=====================开始待分析数据预处理=====================")
    print(">>>>>> 请等待...")
    data_x_all = fun_predict_missing_value(data)                               # 缺失值处理
    data_x_score = fun_predict_MaxMinNormalization(data_x_all)                 # 按'MACHINE_VERSION'联合分组标准化参数指标
    data_predict = fun_predict_Data_get_Classifier(data_x_score)               # 应用数据调用训练模型进行特征选择
    print("=====================结束待分析数据预处理=====================")
    
    return data_predict,data_x_all  # data_predict=经过标化、特征提取处理的值；data_x_all=未经过标化、特征提取处理的值

######################### 应用模型 #############################

def fun_apply_model(X_apply,temp_out_path):
    if model_type=='Logistic模型': job_model = joblib.load(temp_model_path+'\\job_lr_model.pkl')      # Logistic模型
    elif model_type=='SVM模型': job_model = joblib.load(temp_model_path+'\\job_svm_model.pkl')        # SVM模型:
    elif model_type=='随机森林模型': job_model = joblib.load(temp_model_path+'\\job_rfc_model.pkl')   # 随机森林模型        
    elif model_type=='决策树模型': job_model = joblib.load(temp_model_path+'\\job_rf_model.pkl')      # 决策树模型
    elif model_type=='XGBoost模型': job_model = joblib.load(temp_model_path+'\\job_xgb_model.pkl')    # XGBoost模型
    elif model_type=='LightGBM模型': job_model = joblib.load(temp_model_path+'\\job_lgb_model.pkl')   # LightGBM模型
    elif model_type=='模型综合投票': job_model = joblib.load(temp_model_path+'\\job_eclf_model.pkl')   # 模型综合投票
    else:
        print('>>>>>> 没有构建该模型！')
        pass

    Y_predict = pd.DataFrame({'Fault_yc':job_model.predict(X_apply.iloc[:,fixed_field_len:].values)})                                    # 应用模型预测
    Y_model_data = pd.concat([Y_predict,X_apply], axis=1)
    
    # ==============================导出数据=======================================
    if count_i=='多分类[正常_各类别故障]': Y_model_data.to_csv(temp_out_path+'\\预测_多分类-各类故障+正常.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[正常_故障]': Y_model_data.to_csv(temp_out_path+'\\预测_二分类-故障+正常.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[温控阀失效_其他]': Y_model_data.to_csv(temp_out_path+'\\预测_二分类-温控阀失效+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[散热片堵塞_其他]': Y_model_data.to_csv(temp_out_path+'\\预测_二分类-散热片堵塞+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[油泵电机损坏_其他]': Y_model_data.to_csv(temp_out_path+'\\预测_二分类-油泵电机损坏+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_温控阀失效_不能识别故障]': Y_model_data.to_csv(temp_out_path+'\\预测_三分类-正常+温控阀失效+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_散热片堵塞_不能识别故障]': Y_model_data.to_csv(temp_out_path+'\\预测_三分类-正常+散热片堵塞+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_油泵电机损坏_不能识别故障]': Y_model_data.to_csv(temp_out_path+'\\预测_三分类-正常+油泵电机损坏+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='五分类[正常_温控阀失效_散热片堵塞_油泵电机损坏_不能识别故障]': Y_model_data.to_csv(temp_out_path+'\\预测_五分类-正常+温+散+油+其他.csv',index=False,encoding='utf_8_sig')
    else: 
        pass
    
    return Y_model_data