# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 16:09:53 2019

@author: lenovo
"""

from c0_import_zlx import *
from c0_config_zlx import *
from c0_create_time_series import *
from c0_config_create_table_sql import *

# 连接数据库，获取分组字段列表
def fun_get_group_fields_from_oracle(table_name,field_name_sign = 0):                            # 获取分组字段
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                # 连接数据库
    if field_name_sign == 0:
        str_sql_1 = "select distinct t.machine_name \
                     from "+table_name+" t \
                     where t.machine_location in ('吉风','聚风','普发','迅风','麒麟山') \
                     order by t.machine_name"                                                    # 获取“机组名称”  ('吉风','聚风','普发','迅风','麒麟山')
        group_fields = pd.read_sql(str_sql_1,conn)
    elif field_name_sign == 1:
        str_sql_2 = "select distinct t.machine_location,t.machine_version \
                     from "+table_name+" t \
                     where t.machine_location in ('吉风','聚风','普发','迅风','麒麟山') \
                     order by t.machine_name"                                                    # 获取“机场+机组型号”
        group_fields = pd.read_sql(str_sql_2,conn)
    else:
        print('请正确输入参数field_name_sign的值:\n \
              >>>field_name_sign = 0:表示输出“机组”名称;\n \
              >>>field_name_sign = 1:表示输出“机场+机组型号”名称;\n')
        sys.exit(0)                                                                              # 正常退出程序
    conn.close()                                                                                 # 关闭连接   
    return group_fields


# 连接数据库，获取某机组数据
def fun_get_data_unit_from_oracle(table_name,machine_name,columns_name_list):                        # 获取单机组数据
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                    # 连接数据库
    columns_name_list_str = ','.join(columns_name_list)
    print('\n连接数据库，获取某机组数据(1): 表名：',table_name,'； 机组名：',machine_name)
    str_sql = "select "+columns_name_list_str+" from "+table_name+" t \
               where t.machine_name = '"+ machine_name +"' \
               order by t.machine_name,t.LocalTime"

    data_unit_df = pd.read_sql(str_sql,conn)
    data_unit_df = data_unit_df.fillna(np.nan)                                                       # 将数据中'None'列替换为nan
    print('\n连接数据库，获取某机组数据(2)：表名：',table_name,'； 机组名：',machine_name)
    conn.close()                                                                                     # 关闭连接
    return data_unit_df


# 按机组单元处理数据
def fun_data_unit_prepare(data_unit_df,agg_TF):      
    data_unit_df = data_unit_df.drop_duplicates(subset=['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME'],keep='first')  # 单机组内去重(将重复数据保留一个（keep='first）)
    print("\n按机组单元处理数据 :drop_duplicates(2)")
    data_unit_prepare_df = fun_data_unit_time_series_fill(data_unit_df)        # 按风机为单元，填充每个单元不完整的时间序列
    print("\n按机组单元处理数据 :fun_data_unit_time_series_fill(2)")   
    data_unit_prepare_agg_df = fun_data_group_agg(data_unit_prepare_df,agg_TF) # 按风机名称分组滑动聚合(结果包括两个部分：data_unit_prepare[0]为数据框；data_unit_prepare[1]为数据框字段名列表)
    print("\n按机组单元处理数据 :fun_data_group_agg(2)")
    data_unit_prepare = fun_data_group_fault(data_unit_prepare_agg_df[0])      # 定义记录是否处于频繁高温阶段
    print("\n按机组单元处理数据 :fun_data_group_fault(2)")
    return data_unit_prepare


# 按风机名称填充不完整的时间序列
def fun_data_unit_time_series_fill(data_unit_df):
    # 用时间定义pd的索引
    data_unit_df.index = data_unit_df['LOCALTIME']

    # 获取data_group_df的最大，最小时间
    LocalTime_max = data_unit_df['LOCALTIME'].max()
    LocalTime_max_timestamp = pd.to_datetime(LocalTime_max,format='%Y/%m/%d %H:%M:%S')+dateutil.relativedelta.relativedelta(minutes=10)                 # 为最大值加10分钟,因为构建的时间序列是左闭、右开，所以少了一条数据，需要添加
    LocalTime_max = LocalTime_max_timestamp.strftime("%Y-%m-%d %H:%M:%S")
    LocalTime_min = data_unit_df['LOCALTIME'].min()

    # 定义时间序列DataFrame
    time_series_df = pd.DataFrame(Date.date_range(start=LocalTime_min, end=LocalTime_max, freq='10M', out_format=True), columns = ['TIME_SERIES'])      # 生时间序列,freq='10M',为10分钟
    time_series_df.index = time_series_df['TIME_SERIES']                                                                                                # 用时间定义time_series_df的索引

    # 用时间关联数据框
    time_series_df = pd.concat([time_series_df,data_unit_df], axis =1, join_axes=[time_series_df.index])
    time_series_df['LOCALTIME'] = time_series_df['TIME_SERIES']
    time_series_df = time_series_df.iloc[:,1:]                                                                                                          # 删除时间序列字段

    duplicates_df = time_series_df.loc[time_series_df['MACHINE_NAME'].notna(),['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION']].drop_duplicates()  # 从非需要填充的数据中提取待填充内容
    time_series_df[['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION']] = duplicates_df.iloc[0,].tolist()                                             # 填充时序的必填项，即为该机组填充的时间记录填充必要内容

    return time_series_df


# 按风机名称分组滑动聚合（对十分钟均值进行聚合，滑动窗口为8小时（48条数据进行聚合），聚合值为均值、最大值、最小值、标准差、（均值、最大值、最小值、标准差）差分、时间特性等）
def fun_data_group_agg(data_unit_df,agg_TF):
    # 求_avg的均值、标准差、熵、自相关系数，_max的最大值，min的最小值
    data_4_columns = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME']
    data_unit_df['LOCALTIME'] = pd.to_datetime(data_unit_df['LOCALTIME'], errors='coerce')           # 日期类型转化
    # data_unit_df = data_unit_df.sort_values(by=data_4_columns).reset_index(drop = True)            # 为数据排序
    data_unit_df.index = data_unit_df['LOCALTIME']                                                   # 将时间定义为索引
    
    # 对机组的10分钟聚合均值进行差分
    def fun_data_diff_avg(data_unit_df):
        data_columns_name_list = data_unit_df.columns.tolist()
        for i_name in data_columns_name_list:
            if '_' not in i_name:
                continue
            else:
                if i_name.split('_')[1] == 'AVG': 
                    # 均值差分
                    data_unit_df[i_name.split('_')[0]+'_AVGF'] = data_unit_df[i_name].diff(-1)   
                else:
                    continue
        return data_unit_df

    def column_agg(data_unit_temp_df,agg):  # 聚合操作
        data_temp_df = pd.DataFrame(data_unit_temp_df[data_4_columns])
        temp_df = pd.DataFrame()
        for i_name in data_unit_temp_df.columns.tolist():
            if agg == True:  # 是否进行聚合（是）
                if '_' not in i_name:
                    continue
                else:
                    if i_name.split('_')[1] == 'AVG':                                                    # 提取_avg字段
                        # 均值:
                        data_temp_df[i_name.split('_')[0] + '_AVG'] = data_unit_temp_df[i_name]          # 赋均值
                        
                        # 均值的聚合：均值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.mean(x)),raw=False).reset_index()  # raw=False：将每行或每列作为一个系列传递给函数
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVG_G_AVG'] = temp_df[i_name]                # 计算均值    # 移动窗口设为8小时。reset_index()  _AGG_AVG
                        
                        # 均值的聚合：最大值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.maximum(x)),raw=False).reset_index()
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVG_G_MAX'] = temp_df[i_name]                # 计算最大值  # 移动窗口设为8小时。reset_index()  _AGG_MAX
                        
                        # 均值的聚合：最小值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.minimum(x)),raw=False).reset_index()
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVG_G_MIN'] = temp_df[i_name]                # 计算最小值  # 移动窗口设为8小时。reset_index()  _AGG_MIN
    
                        # 均值的聚合：标准差
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.standard_deviation(x)),raw=False).reset_index()  # raw=False：将每行或每列作为一个系列传递给函数
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVG_G_STD'] = temp_df[i_name]                # 计算标准差   # 移动窗口设为8小时。reset_index() _AGG_STD
    
                        # 均值的聚合：离散系数（标准差与平均数的比值,均值越大，相对离散越小）
# =============================================================================
#                         data_temp_df[i_name.split('_')[0]+'_AVG_G_COV'] = data_temp_df[i_name.split('_')[0]+'_AVG_G_STD']/data_temp_df[i_name.split('_')[0]+'_AVG_G_AVG'] 
#                         data_temp_df.loc[(data_temp_df[i_name.split('_')[0]+'_AVG_G_AVG'] == 0),[i_name.split('_')[0]+'_AVG_G_COV']] = 0  # 处理均值为空的离散系数计算
# =============================================================================
    
    # =============================================================================
    #                     # 均值的聚合：熵
    #                     temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.sample_entropy(x)),raw=False).reset_index()
    #                     temp_df.index = data_unit_temp_df['LOCALTIME']
    #                     data_temp_df[i_name.split('_')[0]+'_AVG_G_ENT'] = temp_df[i_name]              # 计算熵      # 移动窗口设为8小时。reset_index()   _AGG_ENT
    # 
    #                     # 均值的聚合：滞后12的自相关系数
    #                     temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.autocorrelation(x,12)),raw=False).reset_index() 
    #                     temp_df.index = data_unit_temp_df['LOCALTIME']
    #                     data_temp_df[i_name.split('_')[0]+'_AVG_G_AUT'] = temp_df[i_name]              # 计算自相关  # 移动窗口设为8小时。reset_index()   _AGG_AUT
    # =============================================================================
    
                    elif i_name.split('_')[1] == 'AVGF':                                                 # 提取_avgf字段
                        # 均值差分:
                        data_temp_df[i_name.split('_')[0] + '_AVGF'] = data_unit_temp_df[i_name]         # 赋均值差分
                        
                        # 均值差分的聚合：均值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.mean(x)),raw=False).reset_index()  # raw=False：将每行或每列作为一个系列传递给函数
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVGF_G_AVG'] = temp_df[i_name]               # 计算均值    # 移动窗口设为8小时。reset_index()   _AGG_AVG
                        
                        # 均值差分的聚合：最大值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.maximum(x)),raw=False).reset_index()
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVGF_G_MAX'] = temp_df[i_name]               # 计算最大值  # 移动窗口设为8小时。reset_index()   _AGG_MAX
                        
                        # 均值差分的聚合：最小值
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.minimum(x)),raw=False).reset_index()
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVGF_G_MIN'] = temp_df[i_name]               # 计算最小值  # 移动窗口设为8小时。reset_index()  _AGG_MIN
    
                        # 均值差分的聚合：标准差
                        temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.standard_deviation(x)),raw=False).reset_index()  # raw=False：将每行或每列作为一个系列传递给函数
                        temp_df.index = data_unit_temp_df['LOCALTIME']
                        data_temp_df[i_name.split('_')[0]+'_AVGF_G_STD'] = temp_df[i_name]               # 计算标准差   # 移动窗口设为8小时。reset_index()   _AGG_STD
                          
                        # 均值差分的聚合：离散系数（标准差与平均数的比值,均值越大，相对离散越小）
# =============================================================================
#                         data_temp_df[i_name.split('_')[0]+'_AVGF_G_COV'] = data_temp_df[i_name.split('_')[0]+'_AVGF_G_STD']/data_temp_df[i_name.split('_')[0]+'_AVGF_G_AVG']
#                         data_temp_df.loc[(data_temp_df[i_name.split('_')[0]+'_AVGF_G_AVG'] == 0),[i_name.split('_')[0]+'_AVGF_G_COV']] = 0  # 处理均值为空的离散系数计算
# =============================================================================
    
    # =============================================================================
    #                     # 均值差分的聚合：熵
    #                     temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.sample_entropy(x)),raw=False).reset_index()
    #                     temp_df.index = data_unit_temp_df['LOCALTIME']
    #                     data_temp_df[i_name.split('_')[0]+'_AVGF_G_ENT'] = temp_df[i_name]             # 计算熵      # 移动窗口设为8小时。reset_index()   _AGG_ENT
    # 
    #                     # 均值差分的聚合：滞后12的自相关系数
    #                     temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.autocorrelation(x,12)),raw=False).reset_index() 
    #                     temp_df.index = data_unit_temp_df['LOCALTIME']
    #                     data_temp_df[i_name.split('_')[0]+'_AVGF_G_AUT'] = temp_df[i_name]             # 计算自相关  # 移动窗口设为8小时。reset_index()   _AGG_AUT
    # =============================================================================
    
# =============================================================================
#                     elif i_name.split('_')[1] == 'MAX':                     
#                         # 提取_max字段
#                         temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.maximum(x)),raw=False).reset_index()
#                         temp_df.index = data_unit_temp_df['LOCALTIME']
#                         data_temp_df[i_name.split('_')[0]+'_MAX_G_MAX'] = temp_df[i_name]                # 计算最大值  # 移动窗口设为8小时。reset_index()  _AGG_MAX
#     
#                     elif i_name.split('_')[1] == 'MIN':                 
#                         # 提取_min字段
#                         temp_df = data_unit_temp_df.groupby(['MACHINE_NAME'],as_index=True)[i_name].rolling(str(8*3600)+'s').apply((lambda x: fc.minimum(x)),raw=False).reset_index()
#                         temp_df.index = data_unit_temp_df['LOCALTIME']
#                         data_temp_df[i_name.split('_')[0]+'_MIN_G_MIN'] = temp_df[i_name]                # 计算最小值  # 移动窗口设为8小时。reset_index()  _AGG_MIN
# =============================================================================
                    else:
                        continue
                    
            else:   # 是否进行聚合（否） 
                if '_' not in i_name:
                    continue
                else:
                    if i_name.split('_')[1] == 'AVG':                                                    # 提取_avg字段
                        # 均值
                        data_temp_df[i_name.split('_')[0]+'_AVG'] = data_unit_temp_df[i_name]
                    elif i_name.split('_')[1] == 'AVGF':                                                 # 提取_avgf字段
                        # 均值的差分
                        data_temp_df[i_name.split('_')[0]+'_AVGF'] = data_unit_temp_df[i_name]           # 均值
                    elif i_name.split('_')[1] == 'STD':     
                        # 标准差 
                        data_temp_df[i_name.split('_')[0]+'_STD'] = data_unit_temp_df[i_name]
                        # 离散系数(标准差/均值)
# =============================================================================
#                         data_temp_df[i_name.split('_')[0]+'_COV'] = data_temp_df[i_name.split('_')[0]+'_STD']/data_temp_df[i_name.split('_')[0]+'_AVG']
#                         data_temp_df.loc[(data_temp_df[i_name.split('_')[0]+'_AVG']==0),[i_name.split('_')[0]+'_COV']] = 0   # 处理均值为空的离散系数计算
# =============================================================================
                    elif i_name.split('_')[1] == 'MAX':  
                        # 最大值 
                        data_temp_df[i_name.split('_')[0]+'_MAX'] = data_unit_temp_df[i_name]
                    elif i_name.split('_')[1] == 'MIN':
                        # 最小值 
                        data_temp_df[i_name.split('_')[0]+'_MIN'] = data_unit_temp_df[i_name]  
                    else:
                        continue
                
        return data_temp_df

    data_unit_diff_avg = fun_data_diff_avg(data_unit_df)                                    # 计算均值差分
    columns_q_list = list(set(data_unit_diff_avg.columns.tolist()) - set(data_4_columns))   # 运行参数字段名列表
    #data_unit_diff_avg = data_unit_diff_avg.loc[data_unit_diff_avg.loc[:,columns_q_list].dropna(axis='index', how='all').index]  # 删除行，条件是整行的运行参数“ 均为 ”NaN ++++++++++++++
    data_unit_diff_avg = data_unit_diff_avg.loc[data_unit_diff_avg.loc[:,columns_q_list].dropna(axis='index', how='any').index]   # 删除行，条件是整行的运行参数“ 存在 ”NaN ++++++++++++++ 
    data_unit_df = column_agg(data_unit_diff_avg,agg_TF)                                    # 滑动聚合特征指标
    feature_columns_list = list(set(data_unit_df.columns.tolist())-set(data_4_columns))     # 特征字段名列表
    feature_columns_list.sort()                                                             # 特征字段名列表排序
    new_columns_name_list = data_4_columns + feature_columns_list                           # 整理字段名列表，将特征字段名排序
    data_unit_df = data_unit_df[new_columns_name_list]
    data_unit_df['LOCALTIME'] = data_unit_df['LOCALTIME'].apply(lambda x: str(x))           # 在输出到数据库前，先将时间字段转换为字符串
    data_unit_df.index = data_unit_df['LOCALTIME']
    return data_unit_df,new_columns_name_list


# 定义记录是否处于频繁高温阶段
def fun_data_group_fault(data_unit_df):
    data_unit_df['LOCALTIME'] = pd.to_datetime(data_unit_df['LOCALTIME'], errors='coerce')                      # 日期类型转化
    #data_unit_df = data_unit_df.sort_values(by=['MACHINE_NAME','LOCALTIME']).reset_index(drop = True)          # 按机组时间排序
    data_unit_df = data_unit_df.sort_values(by=['LOCALTIME']).reset_index(drop = True)                          # 按机组时间排序
    data_unit_df.index = data_unit_df['LOCALTIME']                                                              # 将时间定义为索引
    
    data_unit_df['TEMGEAOIL_GAUGE'] = data_unit_df['TEMGEAOIL_AVG'].apply(lambda x: 1 if x>=65 else 0)          # 0：齿轮箱油温<70 或 nan; 1：齿轮箱油温>=70；
    
    data_columns_list = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME','TEMGEAOIL_GAUGE']
    columns_q_list = list(set(data_unit_df.columns.tolist()) - set(data_columns_list))                             # 运行参数字段名列表
    #data_unit_df = data_unit_df.loc[data_unit_df.loc[:,columns_q_list].dropna(axis='index', how='all').index]  # 删除行，条件是整行的运行参数“ 均为 ”NaN ++++++++++++++
    data_unit_df = data_unit_df.loc[data_unit_df.loc[:,columns_q_list].dropna(axis='index', how='any').index]   # 删除行，条件是整行的运行参数“ 存在 ”NaN ++++++++++++++
    
    #temp_df = data_unit_df.groupby(['MACHINE_NAME'],as_index=True)['TEMGEAOIL_GAUGE'].rolling('1209600s').sum().reset_index()   # 172800s 两天的滑动窗口； 1209600s 14天的滑动窗口
    temp_df = data_unit_df['TEMGEAOIL_GAUGE'].rolling(str(1*24*3600)+'s').sum().reset_index()                   # 172800s 两天的滑动窗口； 1209600s 14天的滑动窗口
    temp_df.index = temp_df.loc[:,'LOCALTIME']                                                                  # 保持与data_unit_df的索引一致
    data_unit_df['TEMGEAOIL_GAUGE'] = temp_df['TEMGEAOIL_GAUGE']
    data_unit_df['TEMGEAOIL_SIGN'] = temp_df['TEMGEAOIL_GAUGE'].apply(lambda x: 'low_risk' if x<1*144*0.6 else 'high_risk')  # 滑动窗口的两天中（288条记录【2016条记录】）有170条【1200条】为齿轮箱温度超过70度，则该记录标记为故障
    
    data_columns_list.append('TEMGEAOIL_SIGN')
    feature_columns_list = list(set(data_unit_df.columns.tolist()) - set(data_columns_list))                       # 特征字段名列表
    feature_columns_list.sort()                                                                                 # 特征字段名列表排序
    data_columns_list.remove('TEMGEAOIL_GAUGE')                                                                    # 删除列表元素
    new_columns_name_list = data_columns_list + feature_columns_list                                               # 整理字段名列表，将特征字段名排序
    data_unit_df = data_unit_df[new_columns_name_list]                                                          # 整理字段顺序后的数据框
    
    data_unit_df.drop_duplicates(subset=feature_columns_list,keep=False,inplace=True)                           # 去重（keep=False，表示将有重复的数据全部删除，不保留）
    
    data_unit_df['LOCALTIME'] = data_unit_df['LOCALTIME'].apply(lambda x: str(x))                               # 在输出到数据库前，先将时间字段转换为字符串
    data_unit_df.index = data_unit_df['LOCALTIME']                                                              # 重新定义索引
    
    return data_unit_df,new_columns_name_list


# 将数据导入Oracle数据库
def fun_data_from_df_to_oracle(data_group_df,ora_table_name = 'USER_DATA_PRE_AGG_ALL'):
    str = 'user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                               # 连接数据库
    cursor = conn.cursor()
    df_column_name = ','.join(data_group_df.columns.values.tolist())
    for indexs in data_group_df.index:
        str_df_unit_value = data_group_df.loc[indexs].values.tolist().__str__()[1:-1]           # 逐行输出值连接起来的字符串
        # print('\nfun_data_from_df_to_oracle(2)-(999-0):',str_df_unit_value)
        str_df_unit_value = str_df_unit_value.replace('nan','null').replace('inf','null').replace('None','null')       # 将字符窜中的"nan","inf"转换为“null”
        # print('\nfun_data_from_df_to_oracle(2)-(999-1):',str_df_unit_value)
        sql_insert = 'insert into '+ora_table_name+' ('+df_column_name+') values ('+str_df_unit_value+')'
        # print('\nfun_data_from_df_to_oracle(2)-(999-2):',sql_insert)
        cursor.execute(sql_insert)
        print('\n（导入机组名称：%s；  导入时间戳：%s）'%(data_group_df.loc[indexs,'MACHINE_NAME'],data_group_df.loc[indexs,'LOCALTIME']))
    conn.commit()
    cursor.close()
    conn.close()


# 在数据库中构建表，表字段的列表为column_name_list
def fun_create_table_oracle(column_name_list,table_name='USER_DATA_PRE_AGG_ALL'):         # 根据字段名建表“USER_DATA_PRE_AGG_ALL”
    empty_list = []
    column_name_dict = agg_data_column_name_dict                               # 获取表信息数据字典
    for column_name_i in column_name_list:
        empty_list.append(column_name_dict[column_name_i])                     # 从数据字典中获取字段类型
    column_name_str = ','.join(empty_list)
    
    sql_create_table ="\
      CREATE TABLE "+table_name+"("+column_name_str+")\
      PCTFREE 10\
      INITRANS 1\
      MAXTRANS 255\
      STORAGE\
      (\
        INITIAL 64K\
        NEXT 1M\
        MINEXTENTS 1\
        MAXEXTENTS UNLIMITED\
      )"
    conn_str ='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(conn_str)                                          # 连接数据库
    cursor = conn.cursor()    
    cursor.execute(sql_create_table)   # 在数据库中创建表
    conn.commit()
    cursor.close()
    conn.close()  


# 在数据表中构建索引
def fun_create_index_oracle(table_name='USER_DATA_PRE_AGG_ALL',table_index_name='AGG_INDEX_NAME'):         # 根据字段名建表“USER_DATA_PRE_AGG_ALL”
    sql_create_index = "CREATE INDEX "+table_index_name+" ON "+table_name+"(MACHINE_LOCATION,MACHINE_VERSION,MACHINE_NAME,LOCALTIME)"
    conn_str ='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(conn_str)                                          # 连接数据库
    cursor = conn.cursor()
    cursor.execute(sql_create_index)   # 在表中创建索引
    conn.commit()
    print('索引构建完成！')
    cursor.close()
    conn.close()


# =============================================================================
# #############################################################################
# =============================================================================   

# # 同步
lock = threading.Lock()   # 申明一个全局的lock对象

# 对单机组数据进行处理+++++++++++++++++++++++++++++++++++++++++++++++++++
def fun_unit_prepare(machine_name_i,data_columns_name_list,data_initial_table_name,data_target_table_name,agg_TF,f_dictValues,f_lock):
    print("\n fun_get_data_unit_from_oracle (1)", machine_name_i)
    data_unit_df = fun_get_data_unit_from_oracle(data_initial_table_name,machine_name_i,data_columns_name_list)      # 获取单机组信息
    print("\n fun_get_data_unit_from_oracle (2)", machine_name_i)

    print("\n fun_data_unit_prepare (1)", machine_name_i)
    data_unit = fun_data_unit_prepare(data_unit_df,agg_TF)                                          # 机组单元数据的数据处理
    print("\n fun_data_unit_prepare (2)", machine_name_i)
# =============================================================================
    column_name_list = data_unit[1]                                                                 # 列名称列表：为聚合后表的列名称
    with f_lock:                                                                                    # 全局的lock对象(不加锁而操作共享的数据,肯定会出现数据错乱)
       f_dictValues['count_run'] += 1                                                               # 进程间共享变量
       if f_dictValues['count_run'] == 1:
          print("\n fun_create_table_oracle (1)", machine_name_i, '；', data_target_table_name)
          fun_create_table_oracle(column_name_list,table_name = data_target_table_name)             # 在数据库中建表，建表时间为首次循环
          print("\n fun_create_table_oracle (2)", machine_name_i, '；', data_target_table_name)
          print('创建数据表：',data_target_table_name)
       else:
          pass
# =============================================================================
    global lock                                                                                     # 引用全局锁(同步)
    lock.acquire()                                                                                  # 申请锁(同步)
    # print("\n fun_data_from_df_to_oracle (1)", machine_name_i, '；', data_target_table_name)
    fun_data_from_df_to_oracle(data_unit[0], ora_table_name = data_target_table_name)               # 将机组处理后数据导入数据库
    # print("\n fun_data_from_df_to_oracle (2)", machine_name_i, '；', data_target_table_name)
    print('将机组"%s"导入数据库' %(machine_name_i))
    lock.release()                                                                                  # 释放锁(同步)
    return data_unit[0]


# 创建多进程调用“单机组数据进行处理”函数
def data_train_pre_multi(machine_name_unit_df,data_columns_name_list,data_initial_table_name,data_target_table_name,processes_num = 6,agg_TF=True):
    M_dictValues = Manager().dict()
    M_lock = Manager().Lock()
    M_dictValues['count_run'] = 0
    
    machine_name_list = machine_name_unit_df['MACHINE_NAME'].tolist()                               # 机组名列表
    with Pool(processes = processes_num) as pool:
         print("进程数量：",processes_num)
         for machine_name in machine_name_list:
             print('\n apply_async(1)',machine_name)
             pool.apply_async(fun_unit_prepare, args = (machine_name,data_columns_name_list,data_initial_table_name,data_target_table_name,agg_TF,M_dictValues,M_lock,))  # 开启多个进程进行数据处理
         pool.close()                                                                               # 关闭进程池，不再接受新的进程
         pool.join()                                                                                # 主进程阻塞等待子进程的退出
    print('数据处理完成!')


# 获取字段名列表，包括保留字段名列表(del_field = False)或删除字段名列表(del_field = True)
def fun_data_get_field(table_name, pre=0.3, del_field = False):                
    str ='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                              # 连接数据库                                                                   

    sql_count = "select t.table_name, t.num_rows, t.last_analyzed  from tabs t where t.table_name ='"+table_name+"'"  # sql字符串，用于获取表的所有记录总数
    data_sql_count = pd.read_sql(sql_count,conn)['NUM_ROWS'][0]                # 调用sql，获取表的所有记录总数
    if data_sql_count.size:
        pass
    else:
        sql_count = "select count(1) as count_num from "+table_name
        data_sql_count = pd.read_sql(sql_count,conn)['COUNT_NUM'][0]
    
    sql_get_str = "select\
                    column_name,\
                     'select '''||column_name||''' as column_name,count('||column_name||') as column_not_null_count\
                      from '||table_name||'\
                      where '||column_name||' is not null union all'\
                      as sql_str\
                    from user_tab_columns where table_name='"+table_name+"' order by column_id"  # sql字符串，获取由查询字符串构成的列表，该系列查询字符串用于查询不同字段的空记录数
    data_sql_str_df = pd.read_sql(sql_get_str,conn)                            # 字段名（column_name），及相应字段非空记录数量（column_not_null_count）
    sql_list_str = ' '.join(data_sql_str_df['SQL_STR'].tolist())[0:-10]        # 获取字符串，该字符串实现 “计算字段的非空记录数”
# =================保留字段：保留非空数据量大于总量的pre倍的字段=================    
    if del_field==False:
        sql_list_str_all = "select * from ("+sql_list_str+") where column_not_null_count >"+repr(data_sql_count*pre)  # 拼接sql语句，实现字段过滤
        data_field_str_df = pd.read_sql(sql_list_str_all,conn)                 # 获取数据框，包括保留的字段名、及该字段的记录数量
        data_hold_columns_name = data_field_str_df['COLUMN_NAME'].tolist()     # 保留字段名列表
        data_columns_name = data_hold_columns_name
    elif del_field==True:
# =================删除字段：删除非空数据量小于总量的pre倍的字段=================
        sql_list_str_all = "select * from ("+sql_list_str+") where column_not_null_count <="+repr(data_sql_count*pre)  # 拼接sql语句，找出需要过滤的字段
        data_field_str_df = pd.read_sql(sql_list_str_all,conn)                 # 获取数据框，包括需要删除字段的字段名、及该字段的记录数量
        data_del_columns_name = data_field_str_df['COLUMN_NAME'].tolist()      # 删除字段名列表
        data_columns_name = data_del_columns_name
# =============================从数据库中删除字段===============================
#         del_colunm_name_str = ','.join(data_del_columns_name)
#         sql_del_colunm = "ALTER TABLE "+table_name+" DROP ("+del_colunm_name_str+")"
#         cursor = conn.cursor()
#         cursor.execute(sql_del_colunm)
#         conn.commit()
#         cursor.close()
# =============================================================================
    else:
        pass
    conn.close()   
    return data_columns_name

# 按非空率提取选择字段
# =============================================================================
# ora_columns_name_list = fun_data_get_field(ora_table_name, pre=0.7, del_field = False)
# =============================================================================

# 70%非空率
# =============================================================================
# ora_columns_name_list = ['MACHINE_NAME', 'MACHINE_VERSION', 'MACHINE_LOCATION', 'LOCALTIME', 'BLADE1POSITION_AVG',
#                          'BLADE1POSITION_MAX', 'BLADE1POSITION_MIN', 'BLADE1POSITION_STD', 'BLADE2POSITION_AVG',
#                          'BLADE2POSITION_MAX', 'BLADE2POSITION_MIN', 'BLADE2POSITION_STD', 'BLADE3POSITION_AVG',
#                          'BLADE3POSITION_MAX', 'BLADE3POSITION_MIN', 'BLADE3POSITION_STD', 'COSCON_AVG', 'COSCON_MAX',
#                          'COSCON_MIN', 'COSCON_STD', 'GENACTIVEPW_AVG', 'GENACTIVEPW_MAX', 'GENACTIVEPW_MIN',
#                          'GENACTIVEPW_STD', 'GENREACTIVEPW_AVG', 'GENREACTIVEPW_MAX', 'GENREACTIVEPW_MIN',
#                          'GENREACTIVEPW_STD', 'GENSPD_AVG', 'GENSPD_MAX', 'GENSPD_MIN', 'GENSPD_STD', 'GRIDFREQ_AVG',
#                          'GRIDFREQ_MAX', 'GRIDFREQ_MIN', 'GRIDFREQ_STD', 'ROTORSPD_AVG', 'ROTORSPD_MAX', 'ROTORSPD_MIN',
#                          'ROTORSPD_STD', 'TEMOUT_AVG', 'TEMOUT_MAX', 'TEMOUT_MIN', 'TEMOUT_STD', 'TOTALTWIST_AVG',
#                          'TOTALTWIST_MAX', 'TOTALTWIST_MIN', 'TOTALTWIST_STD', 'WINDDIRECTION_AVG', 'WINDDIRECTION_STD',
#                          'WINDSPEED_AVG', 'WINDSPEED_MAX', 'WINDSPEED_MIN', 'WINDSPEED_STD', 'TEMGEAMSDE_AVG',
#                          'TEMGEAOIL_AVG', 'WINDVANEDIRECTION_AVG']            
# =============================================================================

# 6个特征
ora_columns_name_list = ['MACHINE_NAME', 'MACHINE_VERSION', 'MACHINE_LOCATION', 'LOCALTIME', 
                         'GENACTIVEPW_AVG','GENACTIVEPW_STD', 'ROTORSPD_AVG', 'ROTORSPD_STD', 'TEMOUT_AVG', 
                         'TEMOUT_STD','WINDSPEED_AVG','WINDSPEED_STD', 'TEMGEAMSDE_AVG', 'TEMGEAOIL_AVG']

# 聚合，并导入数据库中
def fun_data_agg_to_oracel(ora_table_name,ora_agg_table_name,agg_table_index_name,processes_num):
    machine_name_df = fun_get_group_fields_from_oracle(ora_table_name,field_name_sign = 0)                                     # 获取客户数据的机组名列表(USER_DATA_PRE_ALL)
    data_train_pre_multi(machine_name_df,ora_columns_name_list,ora_table_name,ora_agg_table_name,processes_num,agg_TF=True)    # 调用进程对机组数据进行聚合、并导入数据库
    fun_create_index_oracle(table_name=ora_agg_table_name, table_index_name=agg_table_index_name)                              # 为新数据表建立索引

# 主程序
if __name__=='__main__':
    fun_data_agg_to_oracel(**param_prepare_agg_train)
    fun_data_agg_to_oracel(**param_prepare_agg_predict_off)
    #fun_data_agg_to_oracel(**param_prepare_agg_predict_on)