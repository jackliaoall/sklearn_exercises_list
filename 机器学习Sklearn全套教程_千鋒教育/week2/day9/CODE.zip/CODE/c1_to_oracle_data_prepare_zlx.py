# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 13:39:40 2019

@author: lenovo
"""

from c0_import_zlx import *
from c0_config_zlx import *
from c0_public_fun_zlx import *
from c0_config_create_table_sql import *


##################### 在ORACLE数据中创建表 ######################## 
# 在数据库中构建表，表字段的列表为column_name_list
def fun_create_table_oracle(column_name_list,table_name):      # 根据字段名建表“USER_DATA_PRE_ALL”
    empty_list = []
    column_name_dict = initial_data_column_name_dict                           # 获取表信息数据字典
    for column_name_i in column_name_list:
        empty_list.append(column_name_dict[column_name_i])                     # 从数据字典中获取字段类型
    column_name_str = ','.join(empty_list)
    
    sql_create_table ="\
      CREATE TABLE "+table_name+"("+column_name_str+")\
      PCTFREE 10\
      INITRANS 1\
      MAXTRANS 255\
      STORAGE\
      (\
        INITIAL 64K\
        NEXT 1M\
        MINEXTENTS 1\
        MAXEXTENTS UNLIMITED\
      )"
    
    conn_str ='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(conn_str)                                         # 连接数据库
    cursor = conn.cursor()
    cursor.execute(sql_create_table)                                           # 在数据库中创建表
    conn.commit()
    cursor.close()
    conn.close()
    
######################## 为数据表构建索引 ########################
def fun_create_index_oracle(table_name,table_index_name):                       # 根据字段名建表“USER_DATA_PRE_AGG_ALL”
    sql_create_index = "CREATE INDEX "+table_index_name+" ON "+table_name+"(MACHINE_LOCATION,MACHINE_VERSION,MACHINE_NAME,LOCALTIME)"
    conn_str ='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(conn_str)                                          # 连接数据库
    cursor = conn.cursor()
    cursor.execute(sql_create_index)   # 在表中创建索引
    conn.commit()
    print('完成索引创建！')
    cursor.close()
    conn.close()  

##################### 导入ORACLE数据库 ######################## 
def fun_to_Oracle_unit(df_unit,table_name):
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                               # 连接数据库
    cursor=conn.cursor()
    df_column_name = ','.join(df_unit.columns.values.tolist())
    for indexs in df_unit.index:
        str_df_unit_value = df_unit.loc[indexs].values.tolist().__str__()[1:-1]                               # 逐行输出值连接起来的字符串
        str_df_unit_value = str_df_unit_value.replace('nan','null').replace('None','null')                    # 将字符窜中的"nan"、"None"替换为“null”
        sql_insert = 'insert into '+table_name+' ('+df_column_name+') values ('+str_df_unit_value+')'
        cursor.execute(sql_insert)
    conn.commit()
    cursor.close()
    conn.close()

##################### 去误值（-902\850等）、极端值过滤 ######################## 
def fun_data_unit_missing_fill(data_unit_df,features_range):
    data_unit_df = data_unit_df.sort_values(by=['LOCALTIME'])                                                 # 为数据排序  .reset_index(drop = True) 
    data_unit_df = data_unit_df.applymap(lambda x: x if (x not in [-902,850]) else None)                      # 将值为-902、850值替换为 np.nan 
    # ==========================参数值过滤=========================
    for col,range_value in features_range.items():                                                            # 获取列名称和参数范围
        value_min, value_max = range_value                                                                    # 获取参数最大值、最小值
        if col in data_unit_df.columns.tolist():
           data_unit_df.loc[(data_unit_df[col] < value_min) | (data_unit_df[col] > value_max),[col]] = None   # 过滤不符合条件的数据替换为None
        else:
           pass
    return data_unit_df

##################### 解压文件 ################################################ 
def fun_unit_zip(zipname,machine_info_record,machine_locations,time_column,data_machinetype_column,columns_name_list,create_table_name):                
    ZipFiles = zipfile.ZipFile(zipname)
    Files_NameList = ZipFiles.namelist()                                              # 获取csv文件名列表
    for fname in tqdm(Files_NameList, desc='>>>>>> 处理进度', unit='files'):          # 用tqdm模块实现进度条显示
        if fname.endswith('.csv'):                                                    # 判断是否是csv文件
            f_info = ZipFiles.getinfo(fname)
            fo = ZipFiles.open(f_info) 
            df_data_csv = pd.read_csv(fo,encoding='utf_8_sig', na_values='NULL')      # 读取csv文件
            # 单文件内去重(将重复数据保留一个（keep='first，传入参数keep='last'则保留最后一个）)
            df_data_csv = df_data_csv.drop_duplicates(subset=['DeviceId','DeviceName','SiteId','LocalTime'],keep='first')       
            
            filter_cols = data_filter_columns(df_data_csv, data_columns_name)         # 过滤需要的参数列名：保证data中的列名是从data_columns中“引申（聚合运算）”而来；如果不是就剔除掉该列名
            out_unit_data = df_data_csv.loc[:,filter_cols]

            # data_feature_pre(out_unit_data)                                         # 进行参数的数据处理(计算差分)

            device_id = get_machine_id(fname)                                         # 获取文件路径中 "机组ID"
            site_name = get_machine_loaction(machine_locations, fname)                # 获取文件路径中 "机场名称"
            machine_id = site_name+'-'+device_id                                      # "机组ID"与"机场名称"拼接  
            
            out_unit_data[time_column] = df_data_csv[time_column]                     # 补充字段'LocalTime'
            out_unit_data['Machine_name'] = machine_id                                # 机器id
            out_unit_data['Machine_location'] = site_name                             # 机场名称
            if machine_id in list(machine_info_record['风机标识']):
                out_unit_data['Machine_version'] = list(machine_info_record[machine_info_record['风机标识']==machine_id][data_machinetype_column])[0]  # 机器标识
            else:
                continue
            
            # 导入数据库
            out_unit_data.columns = column_transform(out_unit_data, data_columns_map) # 将参数的中文名称转化为英文名称
            df_data_unit = pd.DataFrame(columns = columns_name_list)
            df_data_unit = df_data_unit.append(out_unit_data,sort=False)              # 纵向合并
            df_data_unit = fun_data_unit_missing_fill(df_data_unit,data_range)        # 去误值（-902\850等）、极端值过滤
            fun_to_Oracle_unit(df_data_unit,create_table_name)                        # 导入数据库表中
        else:
            continue
    ZipFiles.close()    

##################### 多进程解压文件 ######################## 
# 创建多进程调用“单机组数据进行处理”函数
def data_pre_multi(zip_path,machine_info_record,machine_locations,time_column,data_machinetype_column,columns_name_list,create_table_name,processes_num = 6):
    with Pool(processes = processes_num) as pool:
         print("进程数量：",processes_num)
         Zips_NameList= getListZips(zip_path)                                         # 获取zip文件名列表
         for zipname in Zips_NameList:      
             if zipname.endswith('.zip'):                                             # 判断是否是zip文件
                print('File_Path_Name:'+zipname)
                pool.apply_async(fun_unit_zip, args = (zipname,machine_info_record,machine_locations,time_column,data_machinetype_column,columns_name_list,create_table_name,))     # 开启多个进程进行数据处理
             else:
                continue        
         pool.close()                                                                                                                               # 关闭进程池，不再接受新的进程
         pool.join()                                                                                                                                # 主进程阻塞等待子进程的退出
    print('数据处理完成!')

##################### 主函数 ########################     
def fun_to_Oracle_all(create_table_name,create_table_index_name,zip_path,time_column,data_machineid_column,
                      data_machinelocation_column,data_starttime_column,data_endtime_column,data_machinetype_column,processes_num):
    #读取档案信息----------------------------------------------------------------------------------------
    machine_info_record = pd.read_excel(machine_info_path,encoding='gbk')                                                                           # 读取档案数据，包含故障和非故障机组信息
    machine_info_record[data_starttime_column] = pd.to_datetime(machine_info_record[data_starttime_column],errors='coerce')                         # 时间类型转化
    machine_info_record[data_endtime_column] = pd.to_datetime(machine_info_record[data_endtime_column],errors='coerce')
    machine_info_record[data_machineid_column] = machine_info_record[data_machineid_column].map(lambda x:str(x))                                    # 机组ID转化为文本
    machine_info_record['风机标识'] = machine_info_record[data_machinelocation_column].str.cat(machine_info_record[data_machineid_column],sep='-')  # 机场名称与机场ID拼接

    machine_locations = machine_info_record[data_machinelocation_column].drop_duplicates().tolist()                                                 # 获取风场名称？**************

    columns_name_list = initial_data_column_name_list                                  # 获取原始数据字段名列表
    fun_create_table_oracle(columns_name_list,create_table_name)                       # 创建数据库表

    # 单进程方式
# =============================================================================
#     Zips_NameList= getListZips(zip_path)                                             # 获取zip文件名列表
#     for zipname in Zips_NameList:      
#         if zipname.endswith('.zip'):                                                 # 判断是否是zip文件
#             print('File_Path_Name:'+zipname)
#             fun_unit_zip(zipname,machine_info_record,machine_locations,time_column,data_machinetype_column,columns_name_list,create_table_name)   # 解压文件到数据库
#         else:
#             continue
# =============================================================================

    # 多进程方式
    data_pre_multi(zip_path,machine_info_record,machine_locations,time_column,data_machinetype_column,columns_name_list,create_table_name,processes_num)  # 多进程解压文件到数据库
    fun_create_index_oracle(create_table_name,create_table_index_name)                 # 为数据库表建立索引

##################### 执行主函数，导入oracle数据库 ########################
# 主程序
if __name__=='__main__':
    fun_to_Oracle_all(**param_prepare_create_train)
    fun_to_Oracle_all(**param_prepare_create_predict_off)
    #fun_to_Oracle_all(**param_prepare_create_predict_on)