# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 17:52:32 2019

@author: lenovo
"""
from c0_import_zlx import *
from c0_config_zlx import *
from c0_create_dir import *
from c7_fault_early_warning_zlx import *


fixed_field_name_list = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME','TARGET_MARK','FAULT_TYPE',
                         'FAULT_TYPE_2CLASS','FAULT_TYPE_2CLASS_W','FAULT_TYPE_2CLASS_S','FAULT_TYPE_2CLASS_Y',
                         'FAULT_TYPE_3CLASS_W','FAULT_TYPE_3CLASS_S','FAULT_TYPE_3CLASS_Y','FAULT_TYPE_5CLASS']  # 固定字段

fixed_field_len = len(fixed_field_name_list)                                    # 固定字段数量

# =============================================================================
# temp_model_path = '\\数据管理\\结果输出\\模型保存\\'
# temp_model_path = mkdir(out_path + temp_model_path + new_train_dir)+'\\'
# temp_model_path = mkdir(temp_model_path + count_type)
# 
# temp_out_path = '\\数据管理\\结果输出\\成果输出\\'
# temp_out_train_path = mkdir(out_path + temp_out_path + new_train_dir)+'\\'
# temp_out_train_path = mkdir(temp_out_train_path + count_type)
# 
# temp_data_path = out_path +'\\数据管理\\预处理好的数据\\训练数据\\'+ new_train_dir+'\\'
# =============================================================================

  
######################### 缺失值处理 #############################

def fun_train_missing_value(data_x):
    data_y = data_x.sort_values(by=['MACHINE_NAME','LOCALTIME']).reset_index(drop = True)
    return data_y

######################### 标准化数据 #############################

def fun_train_MaxMinNormalization(data_x):  
    # 标化到[-1,1]
    max_abs_scaler = preprocessing.MaxAbsScaler()                           # 定义标化模型
    data_x_df = data_x[data_x.columns.values.tolist()[fixed_field_len:]]    # 提取训练数据
    max_abs_scaler.fit(data_x_df)                                           # 训练 max_abs_scaler
    DF_maxAbs = pd.DataFrame(columns = data_x.columns.values.tolist()[fixed_field_len:])    # 定义空的特征指标标化后数据框
    for Machine_version_i in data_x['MACHINE_VERSION'].drop_duplicates().tolist():          # 循环选择风机型号
        data_timp_values = max_abs_scaler.transform(data_x.groupby(['MACHINE_VERSION'])[data_x.columns.values.tolist()[fixed_field_len:]].get_group(Machine_version_i))  # 按风机型号分组标化
        data_timp_df = pd.DataFrame(data_timp_values, index = data_x[data_x['MACHINE_VERSION']==Machine_version_i].index.tolist(), columns = data_x.columns.values.tolist()[fixed_field_len:]) # 将标化值数组转换为数据框，保留data_x中的index
        DF_maxAbs = pd.concat([DF_maxAbs,data_timp_df],axis=0)              # 将多个分组标化数据合并为一个数据框
    y_data = pd.concat([data_x[fixed_field_name_list],DF_maxAbs],axis=1)    # 为分组标化数据对应到相应机组信息
    return y_data


############# 原始数据按机器名称拆分为：建模数据、测试集) ###################
    
# 1.随机抽取不重复的机器名分别作为训练集、和测试集
def fun_train_Data_Machine_split(data_x,fixed_machine_name = True,per=0.90):
    if fixed_machine_name == True:
        Machine_name_test_apply = Machine_name_test                                                               # 测试集：指定抽取测试集的机组名
        Machine_name_train_apply = list(set(data_x['MACHINE_NAME']).difference(set(Machine_name_test)))           # 训练集：抽取训练集的机组名  
    else:
        Machine_name_train_apply = data_x['MACHINE_NAME'].sample(frac=per,random_state=4321).tolist()             # 训练集：随机抽取风机名称中的90%
        Machine_name_test_apply = list(set(data_x['MACHINE_NAME']).difference(set(Machine_name_train_apply)))     # 测试集：就是抽样90%后剩下10%的机组名称

    print('>>>>>> 训练机组名称:',Machine_name_train_apply)
    data_train = data_x[data_x['MACHINE_NAME'].isin(Machine_name_train_apply)].reset_index(drop = True)           # 未被抽中的风机的数据作为训练数据    
    print('>>>>>> 测试机组名称:',Machine_name_test_apply)
    data_test = data_x[data_x['MACHINE_NAME'].isin(Machine_name_test_apply)].reset_index(drop = True)             # 被抽中的风机数据作为测试数据 
    return data_train,data_test


# 1.随机抽取不重复的机器名分别作为训练集、和测试集
# =============================================================================
# def fun_train_Data_Machine_split(data_x,fixed_machine_name = True,per=0.90):
#     if fixed_machine_name == True:
#         Machine_name_test_apply = data_x[data_x['MACHINE_NAME'].isin(Machine_name_test)]                                                              # 测试集：自定义抽取测试集的机组名
#         Machine_name_train_apply = data_x[data_x['MACHINE_NAME'].isin(list(set(data_x['MACHINE_NAME']).difference(set(Machine_name_test))))]          # 训练集：抽取训练集的机组名
#     else:
#         # 该部分与机组名称无关，只是随机抽取记录，适用于单个机组同时用于训练和测试
#         Machine_name_train_apply = data_x.sample(frac=per,random_state=4321)                                      # 训练集：随机抽取风机记录中的90%
#         index =list(set(data_x.index.tolist())-set(data_x.sample(frac=per,random_state=4321).index.tolist()))     # 获取索引，就是抽样90%后剩下10%的记录的索引
#         Machine_name_test_apply = data_x.loc[index,:]
#      
#     print('>>>>>> 训练机组名称:',list(set(data_x['MACHINE_NAME']).difference(set(Machine_name_test))))
#     data_train = Machine_name_train_apply
#     print('>>>>>> 训练机组名称:',Machine_name_test)
#     data_test = Machine_name_test_apply
#
#     return data_train,data_test
# =============================================================================


##############基于树模型进行特征选择 ###################

def fun_train_Data_Classifier(data_x):                                                                  # 特征选择
    field_name = data_x.columns.values.tolist()                                                         # 获取字段名列表
    X = data_x[field_name[fixed_field_len:]]                                                            # 所有特征变量
    y = data_x[Fault_type_name]                                                                         # 故障类型变量，Fault_type_name 公有变量

    clf_classifier_model = ExtraTreesClassifier()                                                       # 特征重要性模型
    clf_classifier_model = clf_classifier_model.fit(X.values,y.values)                                  # 获取特征重要性

    job_classifier_model = SelectFromModel(clf_classifier_model, threshold='1.25*mean', prefit=True)    # 特征选择：选择特征重要性为1.25倍均值的特征
    X_df = data_x[field_name[fixed_field_len:]]                                                         # 待筛选特征变量
    X_trees = job_classifier_model.transform(X_df)                                                      # 返回所选的特征
    print('>>>>>> 完成训练特征选择！')
    print('>>>>>> 训练特征集向量：',X_trees.shape)

    X_trees_df = pd.DataFrame(X_trees, index=X_df.index)
    X_trees_df.columns = X_df.columns[job_classifier_model.get_support()]                               # 为特征字段填充字段名称
    print('>>>>>> 训练特征名称：',X_trees_df.columns.tolist())
    data_y = pd.concat([data_x[field_name[0:fixed_field_len]], X_trees_df], axis=1)                     # 在axis=1 时为横向拼接。

    joblib.dump(job_classifier_model, temp_model_path+'\\job_classifier_model.pkl')                                    # 保存特征选择重要性模型
    print('>>>>>> 保存特征选择模型：job_classifier_model 到'+temp_model_path+'\job_classifier_model.pkl')               # 输出特征选择模型

    df_importance = pd.DataFrame(clf_classifier_model.feature_importances_, columns=['特征重要性'], index=field_name[fixed_field_len:]).sort_values(by='特征重要性', ascending=False)  # 特征重要性(数值越高特征越重要)
    df_importance.to_csv(temp_out_train_path+'\\特征重要性.csv', index=True, encoding='utf_8_sig')                            # 输出特征重要性

    return data_y


def fun_train_Data_get_Classifier(data_x):                                                                                                   # 加载模型进行特征选择
    field_name = data_x.columns.values.tolist()
    job_classifier_model = joblib.load(temp_model_path+'\\job_classifier_model.pkl')                                    # 加载模型
    X_df = data_x[field_name[fixed_field_len:]]
    X_trees = job_classifier_model.transform(X_df)

    print('>>>>>> 完成验证特征选择！')                                                                                                        # 返回所选的特征
    print('>>>>>> 验证特征集向量：',X_trees.shape)
    X_trees_df = pd.DataFrame(X_trees, index=X_df.index)
    X_trees_df.columns = X_df.columns[job_classifier_model.get_support()]
    print('>>>>>> 验证特征名称：',X_trees_df.columns.tolist())
    
    data_y = pd.concat([data_x[field_name[0:fixed_field_len]], X_trees_df], axis=1)  # 在axis=1 时为横向拼接。
    return data_y


######################### 多分类模型的评估方法之--kappa系数 ####################
# https://blog.csdn.net/wang7807564/article/details/80252362
    
def fun_kappa(matrix):  # 这个系数的取值范围是[-1,1]，实际应用中，一般是[0,1]，这个系数的值越高，则代表模型实现的分类准确度越高。
    n = np.sum(matrix)
    sum_po = 0
    sum_pe = 0
    for i in range(len(matrix[0])):
        sum_po += matrix[i][i]
        row = np.sum(matrix[i, :])
        col = np.sum(matrix[:, i])
        sum_pe += row * col
    po = sum_po / n
    pe = sum_pe / (n * n)
    # print(po, pe)
    return (po - pe) / (1 - pe)

######################### 绘制混淆矩阵 #############################

def fun_plot_confusion_matrix(y_true, y_pred, labels):
    cmap = plt.cm.binary
    cm = confusion_matrix(y_true, y_pred, labels)   # labels :关于类别顺序可由 labels参数控制调整
    print(cm)
    tick_marks = np.array(range(len(labels))) + 0.5
    np.set_printoptions(precision=2)
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    plt.figure(figsize=(10, 8), dpi=120)
    ind_array = np.arange(len(labels))
    x, y = np.meshgrid(ind_array, ind_array)
    intFlag = 0 # 标记在图片中对文字是整数型还是浮点型
    for x_val, y_val in zip(x.flatten(), y.flatten()):
        if (intFlag):
            c = cm[y_val][x_val]
            plt.text(x_val, y_val, "%d" % (c,), color='red', fontsize=8, va='center', ha='center')

        else:
            c = cm_normalized[y_val][x_val]
            if (c > 0.01):
                #这里是绘制数字，可以对数字大小和颜色进行修改
                plt.text(x_val, y_val, "%0.2f" % (c,), color='red', fontsize=7, va='center', ha='center')
            else:
                plt.text(x_val, y_val, "%d" % (0,), color='red', fontsize=7, va='center', ha='center')
    if(intFlag):
        plt.imshow(cm, interpolation='nearest', cmap=cmap)
    else:
        plt.imshow(cm_normalized, interpolation='nearest', cmap=cmap)
    plt.gca().set_xticks(tick_marks, minor=True)
    plt.gca().set_yticks(tick_marks, minor=True)
    plt.gca().xaxis.set_ticks_position('none')
    plt.gca().yaxis.set_ticks_position('none')
    plt.grid(True, which='minor', linestyle='-')
    plt.gcf().subplots_adjust(bottom=0.15)
    plt.title('')
    plt.colorbar()
    xlocations = np.array(range(len(labels)))
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文字体设置
    plt.xticks(xlocations, labels, rotation=90)
    plt.yticks(xlocations, labels)
    plt.ylabel('真实值')
    plt.xlabel('预测值')
    plt.show()
    
######################### 建立模型 #############################
# 建立模型

def fun_model_evaluation(X_test,y_test,yc_test,X_name_list):    # 模型效果验证指标输出
    fault_yc = pd.DataFrame(yc_test)
    fault_yc.columns=['Fault_yc']                               # 预测值
    fault_y = pd.DataFrame(y_test[:,Fault_i])
    fault_y.columns=['Fault_y']                                 # 测试因变量
    data_machine_name = pd.DataFrame(y_test[:,0])    
    data_machine_name.columns=['MACHINE_NAME']                  # 机器名称
    data_location_name = pd.DataFrame(y_test[:,2])
    data_location_name.columns=['MACHINE_LOCATION']             # 场站名称
    data_time = pd.DataFrame(y_test[:,3])
    data_time.columns=['LOCALTIME']                             # 测试数据时间轴
    data_X_test = pd.DataFrame(X_test)
    data_X_test.columns = X_name_list                           # 为自变量附列名
    data_df = pd.concat([fault_yc, fault_y, data_machine_name, data_location_name, data_time, data_X_test], axis=1)  # 横向拼接(预测值、实际值、机器名称、场站名称、时间点)
    labels_name = fault_y['Fault_y'].drop_duplicates().values.tolist()
    
    print(">>>>>> 正确率:",metrics.accuracy_score(data_df['Fault_y'], data_df['Fault_yc'], labels_name)*100,"%")
    
    data_precision = metrics.precision_score(data_df['Fault_y'], data_df['Fault_yc'], labels_name, average=None)     # 真阳/(真阳+假阳) ： 100个被预测为真值的结果中，有多少个预测正确 
    print(">>>>>> 查准率:",data_precision*100,"%")    
    print(">>>>>> 平均查准率:",np.mean(data_precision)*100,"%")
    
    data_recall = metrics.recall_score(data_df['Fault_y'], data_df['Fault_yc'], labels_name, average=None)           # 真阳/(真阳+假阴) ： 100个真中有多少个被预测准确
    print(">>>>>> 查全率:",data_recall*100,"%")       
    print(">>>>>> 平均查全率:",np.mean(data_recall)*100,"%")
    
    data_F1 = metrics.f1_score(data_df['Fault_y'], data_df['Fault_yc'], labels_name, average='weighted')             # F1-score 越高，说明分类模型越稳健。
    print(">>>>>> F1_得分:",data_F1)                 
    
    data_matrix = confusion_matrix(data_df['Fault_y'], data_df['Fault_yc'], labels_name)                             # labels :关于类别顺序可由 labels参数控制调整
    print(">>>>>> kappa系数:",fun_kappa(data_matrix))
    print(">>>>>> 混淆矩阵:")
    fun_plot_confusion_matrix(data_df['Fault_y'], data_df['Fault_yc'], labels_name)                                  # 绘制混淆矩阵
    
    return data_df

def fun_create_model(X_train,y_train,X_test,y_test,X_test_name_list):   # 创建模型
    lr_model = LogisticRegression(C=2,class_weight='balanced')          # logistic回归,| class_weight参数用于标示分类模型中各种类型的权重，可以不输入，即不考虑权重，可以选择balanced让类库自己计算类型权重  | ,multi_class='ovr':多分类时使用 ovr: one vs rest 
    rfc_model = RandomForestClassifier()                                # 随机森林
    rf_model = DecisionTreeClassifier()                                 # 决策树模型
    xgb_model = XGBClassifier()                                         # XGBoost 所应用的算法就是 GBDT（gradient boosting decision tree）的改进，既可以用于分类也可以用于回归问题中。
    lgb_model = LGBMClassifier()                                        # 分类是LGBMClassifier，回归是LGBMRegressor。
    eclf_model = VotingClassifier(estimators=[('lr',lr_model),('rfc',rfc_model),('rf',rf_model),('xgb',xgb_model),('lgb',lgb_model)], voting='soft')
    
    yy_train = y_train[:,Fault_i]    
    
    job_lr_model = lr_model.fit(X_train,yy_train)                                                   # 训练模型
    print(">>>>>> 1-Logistic模型:")
    lr_out = fun_model_evaluation(X_test,y_test,job_lr_model.predict(X_test),X_test_name_list)      # 调用模型，输出验证结果
    joblib.dump(job_lr_model,temp_model_path+'\\job_lr_model.pkl')           # 保存模型
    print(">>>>>> 完成Logistic模型训练,并保存模型！\n")

    job_rfc_model = rfc_model.fit(X_train,yy_train)
    print(">>>>>> 2-随机森林模型:")
    rfc_out = fun_model_evaluation(X_test,y_test,job_rfc_model.predict(X_test),X_test_name_list)    # 调用模型，输出验证结果
    joblib.dump(job_rfc_model,temp_model_path+'\\job_rfc_model.pkl')         # 保存模型
    print(">>>>>> 完成随机森林模型训练,并保存模型！\n")
 
    job_rf_model = rf_model.fit(X_train,yy_train)
    print(">>>>>> 3-决策树模型:")
    rf_out = fun_model_evaluation(X_test,y_test,job_rf_model.predict(X_test),X_test_name_list)      # 调用模型，输出验证结果
    joblib.dump(job_rf_model,temp_model_path+'\\job_rf_model.pkl')           # 保存模型
    print(">>>>>> 完成决策树模型训练,并保存模型！\n")
 
    job_xgb_model = xgb_model.fit(X_train,yy_train)                            
    print(">>>>>> 4-XGBoost模型:")
    xgb_out = fun_model_evaluation(X_test,y_test,job_xgb_model.predict(X_test),X_test_name_list)    # 调用模型，输出验证结果
    joblib.dump(job_xgb_model,temp_model_path+'\\job_xgb_model.pkl')         # 保存模型
    print(">>>>>> 完成XGBoost模型训练,并保存模型！\n")
 
    job_lgb_model = lgb_model.fit(X_train,yy_train)
    print(">>>>>> 5-LightGBM模型:")
    lgb_out = fun_model_evaluation(X_test,y_test,job_lgb_model.predict(X_test),X_test_name_list)    # 调用模型，输出验证结果
    joblib.dump(job_lgb_model,temp_model_path+'\\job_lgb_model.pkl')         # 保存模型
    print(">>>>>> 完成LightGBM模型训练,并保存模型！\n")
 
    job_eclf_model = eclf_model.fit(X_train,yy_train)
    print(">>>>>> 6-模型综合投票:")
    eclf_out = fun_model_evaluation(X_test,y_test,job_eclf_model.predict(X_test),X_test_name_list)  # 调用模型，输出验证结果
    joblib.dump(job_eclf_model,temp_model_path+'\\job_eclf_model.pkl')       # 保存模型
    print(">>>>>> 完成模型综合投票,并保存模型！\n")

    # ==============================导出数据=======================================
    if model_type =='Logistic模型': out_model = lr_out
    elif model_type =='SVM模型': out_model = svm_out    
    elif model_type =='随机森林模型': out_model = rfc_out
    elif model_type =='决策树模型': out_model = rf_out
    elif model_type =='XGBoost模型': out_model = xgb_out
    elif model_type =='LightGBM模型': out_model = lgb_out   
    elif model_type =='模型综合投票': out_model = eclf_out   
    else:
        print('>>>>>> 没有构建该模型！')
        pass

    if count_i=='多分类[正常_各类别故障]': out_model.to_csv(temp_out_train_path+'\\验证_多分类-各类故障+正常.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[正常_故障]': out_model.to_csv(temp_out_train_path+'\\验证_二分类-故障+正常.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[温控阀失效_其他]': out_model.to_csv(temp_out_train_path+'\\验证_二分类-温控阀失效+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[散热片堵塞_其他]': out_model.to_csv(temp_out_train_path+'\\验证_二分类-散热片堵塞+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='二分类[油泵电机损坏_其他]': out_model.to_csv(temp_out_train_path+'\\验证_二分类-齿轮箱漏油+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_温控阀失效_不能识别故障]': out_model.to_csv(temp_out_train_path+'\\验证_三分类-正常+温控阀失效+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_散热片堵塞_不能识别故障]': out_model.to_csv(temp_out_train_path+'\\验证_三分类-正常+散热片堵塞+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='三分类[正常_油泵电机损坏_不能识别故障]': out_model.to_csv(temp_out_train_path+'\\验证_三分类-正常+齿轮箱漏油+其他.csv',index=False,encoding='utf_8_sig')
    elif count_i=='五分类[正常_温控阀失效_散热片堵塞_油泵电机损坏_不能识别故障]': out_model.to_csv(temp_out_train_path+'\\验证_五分类-正常+温+散+齿+其他.csv',index=False,encoding='utf_8_sig')
    else: 
        pass

    return out_model


# =============================================================================
########################### 项目分析  ##############################
# =============================================================================

def fun_train_model_apply():        # 训练数据应用
    if Machine_location:            # 同机场、同型号
        if Machine_version_UP:
           # 按机场、机组型号拆分数据
           f_open = open(temp_train_path + '['+Machine_location_name+'_'+Machine_version_name+']_Data_DF_xy.csv',encoding='utf_8_sig')
        else:
           # 按机场、机组型号后四位输出数据
           f_open = open(temp_train_path + '['+Machine_location_name+'_'+Machine_version_code+']_Data_DF_xy.csv',encoding='utf_8_sig')
    else:                           # 不同机场、同型号
        if Machine_version_UP:
           # 按机场、机组型号拆分数据
           f_open = open(temp_train_path + '['+Machine_version_name+']_Data_DF_xy.csv',encoding='utf_8_sig')
        else:
           # 按机场、机组型号后四位输出数据
           f_open = open(temp_train_path + '['+Machine_version_code+']_Data_DF_xy.csv',encoding='utf_8_sig')

    print(">>>>>> 训练数据读取中，请等待...")
    data_all = pd.read_csv(f_open)  # 读取训练数据

    # =========================================================================按机器名称占比拆分
    print("\n=====================开始待建模数据预处理======================")
    print(">>>>>> 请等待...")
    data_xy_all = fun_train_missing_value(data_all)                                      # 缺失值处理
    data_xy_all = data_xy_all[data_xy_all['FAULT_TYPE'].isin(Fault_name_train)]          # 用全局变量Fault_name_train过滤故障类型
    data_xy_Normalization = fun_train_MaxMinNormalization(data_xy_all)                   # 按'MACHINE_VERSION'联合分组标准化参数指标
    data_train,data_test = fun_train_Data_Machine_split(data_xy_Normalization, fixed_machine_name = True, per=0.95)  # 按自定义机组名抽取训练集、验证集

    data_train_Classifier = fun_train_Data_Classifier(data_train)                        # 训练数据特征选择
    data_test_Classifier = fun_train_Data_get_Classifier(data_test)                      # 验证数据调用训练模型进行特征选择
    print("\n=====================结束待建模数据预处理======================")

    data_model_x = data_train_Classifier.iloc[:,fixed_field_len:].values
    data_model_y = data_train_Classifier.iloc[:,0:fixed_field_len].values 
    data_test_x = data_test_Classifier.iloc[:,fixed_field_len:].values
    data_test_y = data_test_Classifier.iloc[:,0:fixed_field_len].values
    X_name_list = data_test_Classifier.iloc[:,fixed_field_len:].columns.tolist()

    print("\n=====================展示验证数据的模型效果=====================")
    out_data_model = fun_create_model(data_model_x,data_model_y,data_test_x,data_test_y,X_name_list)      # 建模，并测试数据进行
    # fun_fault_early_warning(out_data_model,'验证',temp_out_train_path)                                  # 输出成果

    df_temp_early_warning = fun_fault_early_warning(out_data_model,'验证',temp_out_train_path)            # 输出最终报警成果
    # 通过df_temp_early_warning返回的机组名、时间标记，用数据data_list[1]绘图
    for (machine_name_i,fault_yc_i,localtime_i) in zip(df_temp_early_warning['MACHINE_NAME'].tolist(),df_temp_early_warning['Fault_yc'].tolist(),df_temp_early_warning['LOCALTIME'].tolist()):
        data_fault = data_xy_all.loc[data_xy_all['MACHINE_NAME']==machine_name_i,].sort_values(by= ['MACHINE_NAME','LOCALTIME'])
        fun_data_plot(data_fault,machine_name_i,fault_yc_i,localtime_i,temp_out_train_plot_path)

# 主程序
if __name__=='__main__':
    fun_train_model_apply()

