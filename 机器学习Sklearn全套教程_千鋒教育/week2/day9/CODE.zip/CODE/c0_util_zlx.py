#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time : 2019/1/15 下午8:54
# @Author : wangweichao
# @File : project.py
"""
整个项目的结构
"""

from c0_import_zlx import *
from c0_config_zlx import *

class Project:

    def __init__(self,root_dir):
        self._root_dir = root_dir
        self._init_all_paths()

    def _init_all_paths(self):
        self._code_dir = os.path.join(self._root_dir, '数据管理')  # 存放输入输出数据
        
        self._data_in_dir = os.path.join(self._code_dir, '原始数据')  # 存放原始数据  附属部件故障记录\机组信息
        self._data_in_train_dir = os.path.join(self._data_in_dir, '用于训练的原始数据')  # 存放用于训练的原始数据  DATA_201711_201805
        self._data_in_test_off_dir = os.path.join(self._data_in_dir, '离线测试的原始数据')  # 存放用于测试的原始数据   DATA_201806_201812
        self._data_in_test_on_dir = os.path.join(self._data_in_dir, '在线测试的原始数据')  # 存放用于测试的原始数据   DATA_201806_201812
        
        self._data_out_dir = os.path.join(self._code_dir, '预处理好的数据')           # 存放预处理好的数据
        self._data_out_train_dir = os.path.join(self._data_out_dir, '训练数据')       # 存放训练数据  model_xy
        self._data_out_test_off_dir = os.path.join(self._data_out_dir, '离线测试数据')    # 存放测试数据  apply_x
        
        self._result_out_dir = os.path.join(self._code_dir, '结果输出')               # 结果输出
        self._result_out_model_dir = os.path.join(self._result_out_dir, '模型保存')   # 模型保存 

        
        self._result_out_csv_dir = os.path.join(self._result_out_dir, '成果输出')                                        # 成果输出


    # 设置成只读属性
    @property
    def root_dir(self):
        return self._root_dir + os.path.sep

    @property    
    def code_dir(self):
        return self._code_dir + os.path.sep

    @property
    def data_in_dir(self):
        return self._data_in_dir + os.path.sep

    @property
    def data_in_train_dir(self):
        return self._data_in_train_dir + os.path.sep

    @property
    def data_in_test_off_dir(self):
        return self._data_in_test_off_dir + os.path.sep
    
    @property
    def data_in_test_on_dir(self):
        return self._data_in_test_on_dir + os.path.sep

    @property
    def data_out_dir(self):
        return self._data_out_dir + os.path.sep

    @property
    def data_out_train_dir(self):
        return self._data_out_train_dir + os.path.sep

    @property
    def data_out_test_off_dir(self):
        return self._data_out_test_off_dir + os.path.sep

    @property
    def result_out_dir(self):
        return self._result_out_dir + os.path.sep
    
    @property
    def result_out_model_dir(self):
        return self._result_out_model_dir + os.path.sep
    
    @property
    def result_out_csv_dir(self):
        return self._result_out_csv_dir + os.path.sep

    @staticmethod
    def init(root_dir,create_dir = True):
        """
        :param root_dir:项目根目录
        :param create_dir:是否需要重新创建项目存放的资料目录
        :return:放回项目操作的对象
        """
        project = Project(root_dir)
        if create_dir:
            paths_to_create = [
                project.code_dir,
                project.data_in_dir,
                project.data_in_train_dir,
                project.data_in_test_off_dir,
                project.data_in_test_on_dir,
                project.data_out_dir,
                project.data_out_train_dir,
                project.data_out_test_off_dir,
                project.result_out_dir,
                project.result_out_model_dir,              
                project.result_out_csv_dir
            ]
            for path in paths_to_create:
                if os.path.exists(path):
                    continue
                else:
                    os.makedirs(path)
        return project

# 初始化整个项目的基础类
project = Project.init(out_path,create_dir=True)
