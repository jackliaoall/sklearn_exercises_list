# -*- coding: utf-8 -*-
"""
Created on Thu Apr  4 14:25:54 2019

@author: lenovo
"""
from c0_import_zlx import *
from c0_config_zlx import *
from c0_public_fun_zlx import *
from c0_create_dir import *

# =============================================================================
# temp_train_path = '\\数据管理\\预处理好的数据\\训练数据\\'
# temp_train_path = mkdir(out_path + temp_train_path + new_train_dir)+'\\'
# =============================================================================

#######################重新定义故障类型字段###############################
def getFiled(data_df,id_plan):  
    type_values=''
    Fault_type_values = data_df['FAULT_TYPE']

    if id_plan == 1 :
        if Fault_type_values=='正常':
            type_values = '正常'
        else:
            type_values = '故障'

    elif id_plan == 2 :
        if Fault_type_values=='温控阀失效':
            type_values = '温控阀失效'
        else:
            type_values = '其他'

    elif id_plan == 3 :
        if Fault_type_values=='散热片堵塞':
            type_values = '散热片堵塞'
        else:
            type_values = '其他'  

    elif id_plan == 4 :
        if Fault_type_values=='油泵电机损坏':
            type_values = '油泵电机损坏'
        else:
            type_values = '其他'   

    elif id_plan == 5 :
        if Fault_type_values=='正常':
            type_values = '正常'
        elif Fault_type_values=='温控阀失效':
            type_values = '温控阀失效' 
        else:
            type_values = '其他'  

    elif id_plan == 6 :
        if Fault_type_values=='正常':
            type_values = '正常'
        elif Fault_type_values=='散热片堵塞':
            type_values = '散热片堵塞' 
        else:
            type_values = '其他'  
            
    elif id_plan == 7 :
        if Fault_type_values=='正常':
            type_values = '正常'
        elif Fault_type_values=='油泵电机损坏':
            type_values = '油泵电机损坏' 
        else:
            type_values = '其他'  

    elif id_plan == 8 :
        if Fault_type_values=='正常':
            type_values = '正常'
        elif Fault_type_values=='温控阀失效':
            type_values = '温控阀失效' 
        elif Fault_type_values=='散热片堵塞':
            type_values = '散热片堵塞' 
        elif Fault_type_values=='油泵电机损坏':
            type_values = '油泵电机损坏' 
        else:
            type_values = '其他' 

    return type_values

# =============================================================================
# # 连接数据库，获取分组字段列表
# =============================================================================
def fun_get_group_fields_from_oracle(table_name,field_name_sign = 0):                            # 获取分组字段
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                # 连接数据库
    if field_name_sign == 0:
        str_sql_1 = "select distinct t.machine_name \
                     from "+table_name+" t \
                     order by t.machine_name"                                                    # 获取“机组名称”                                             
        group_fields = pd.read_sql(str_sql_1,conn)
    elif field_name_sign == 1:
        str_sql_2 = "select distinct t.machine_location,t.machine_version \
                     from "+table_name+" t \
                     order by t.machine_name"                                                    # 获取“机场+机组型号”
        group_fields = pd.read_sql(str_sql_2,conn)
    else:
        print('请正确输入参数field_name_sign的值:\n \
              >>>field_name_sign = 0:表示输出“机组”名称;\n \
              >>>field_name_sign = 1:表示输出“机场+机组型号”名称;\n')
        sys.exit(0)                                                                              # 正常退出程序
    conn.close()                                                                                 # 关闭连接   
    return group_fields


# =============================================================================
# # 连接数据库，获取某机组数据
# =============================================================================
def fun_get_data_unit_from_oracle(machine_name,table_name):                                      # 获取单机组数据
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                # 连接数据库
    str_sql = "select * from "+ table_name +" t  \
               where t.machine_name = '"+ machine_name +"' \
               order by t.machine_name,t.LocalTime"                                              # 训练集提取
    data_unit_df = pd.read_sql(str_sql,conn)
    conn.close()                                                                                 # 关闭连接
    return data_unit_df

# =============================================================================
# 标注故障类型
# =============================================================================
def fun_prepare_data_train(ora_table_name,time_column,data_machineid_column,data_machinetype_column,data_machinelocation_column,data_starttime_column,
            data_endtime_column,fault_machineid_column,fault_machinelocation_column,fault_starttime_column,fault_endtime_column,fault_reason_column,
            fault_type_column,use_start=True,data_all_days=2,fault_days=14,normal_startday=90,normal_endday=120):
    
    #读取故障信息----------------------------------------------------------------------------------------
    machine_record = pd.read_excel(machine_path,encoding='gbk')                                                                         # 读取故障记录
    machine_record = machine_record.drop_duplicates()                                                                                   # 故障信息表去重
    machine_record[fault_starttime_column] = pd.to_datetime(machine_record[fault_starttime_column],errors='coerce')                     # 开始时间类型转化
    machine_record[fault_endtime_column] = pd.to_datetime(machine_record[fault_endtime_column],errors='coerce')                         # 结束时间类型转化
    machine_record[fault_machineid_column] = machine_record[fault_machineid_column].map(lambda x:str(x))                                # 机组ID转化为文本
    machine_record['风机标识'] = machine_record[fault_machinelocation_column].str.cat(machine_record[fault_machineid_column],sep='-')   # 添加字段“风机标识”：机场名称与机场ID拼接，例如“讯风”+“-”+“22”=“讯风-22”
   
    #读取档案信息----------------------------------------------------------------------------------------
    machine_info_record = pd.read_excel(machine_info_path,encoding='gbk')                                                               # 读取档案数据，包含故障和非故障机组信息
    machine_info_record = machine_info_record.drop_duplicates()                                                                         # 档案信息去重
    machine_info_record[data_starttime_column] = pd.to_datetime(machine_info_record[data_starttime_column],errors='coerce')             # 开始时间类型转化
    machine_info_record[data_endtime_column] = pd.to_datetime(machine_info_record[data_endtime_column],errors='coerce')                 # 结束时间类型转化
    machine_info_record[data_machineid_column] = machine_info_record[data_machineid_column].map(lambda x:str(x))                        # 机组ID转化为文本
    machine_info_record['风机标识'] = machine_info_record[data_machinelocation_column].str.cat(machine_info_record[data_machineid_column],sep='-') # 机场名称与机场ID拼接   
    
    fault_machines = machine_record['风机标识'].drop_duplicates().tolist()                                                               # 获取所有故障机组    
    fault_machines_fs = machine_record.loc[machine_record[fault_type_column]=='附属部件','风机标识'].drop_duplicates().tolist()          # 获取所有附属部件故障机组

    #每个机组维护一张故障信息表
    machine_fault_all_record_dict = {}     # 故障机组与故障记录构成的数据字典
    for fault_machines_id in fault_machines: 
        temp_data = machine_record.loc[machine_record['风机标识']==fault_machines_id, ]         # 某个机组的所有故障记录
        machine_fault_all_record_dict[fault_machines_id] = temp_data                            # 字典填充

    machine_fault_fs_all_record_dict = {}  # 附属部件故障机组与故障记录构成的数据字典
    for fault_machines_fs_id in fault_machines_fs: 
        temp_data = machine_record.loc[(machine_record['风机标识']==fault_machines_fs_id) & (machine_record[fault_type_column]=='附属部件'), ]      # 某个机组的附属故障记录
        machine_fault_fs_all_record_dict[fault_machines_fs_id] = temp_data                      # 字典填充

    machine_name_DF = fun_get_group_fields_from_oracle(ora_table_name,field_name_sign = 0)      # 获取客户数据的机组名数据框 
    machine_name_list = machine_name_DF['MACHINE_NAME'].tolist()                                # 将数据框转换为机组名列表
    machine_DFList = []    
    for machine_name_i in tqdm(machine_name_list, desc='>>>>>> 处理进度', unit='files'):
        data = fun_get_data_unit_from_oracle(machine_name_i,ora_table_name)                     # 连接数据库，获取某机组数据
        data[time_column] = pd.to_datetime(data[time_column], errors='coerce')                  # 日期类型转换
        
        filter_cols = data.columns.tolist()                                                     # 提取需要的参数列名
        
        data_low = data.loc[data['TEMGEAOIL_SIGN']=='low_risk',]                                # 低风险区数据
        data_high = data.loc[data['TEMGEAOIL_SIGN']=='high_risk',]                              # 高风险区（油温高概率超限）数据
    
        if data.empty:
            pass
        else:
            machine_start_time = pd.DataFrame()                                                 # 机组在机组信息表中的开始时间
            machine_end_time = pd.DataFrame()                                                   # 机组在机组信息表中的结束时间
            if machine_name_i not in machine_info_record['风机标识'].drop_duplicates().tolist():
                pass
            else:
                machine_start_time = list(machine_info_record[machine_info_record['风机标识']==machine_name_i][data_starttime_column])[0]  # 获取当前机组的数据开始时间
                machine_end_time = list(machine_info_record[machine_info_record['风机标识']==machine_name_i][data_endtime_column])[0]      # 获取当前机组的数据结束时间
    
            machine_fault_all_record = pd.DataFrame()                                           # 定义变量，保存机组在故障信息表中的所有故障记录
            if machine_name_i not in fault_machines:                                            # list(machine_record['风机标识']):
                pass
            else:
                machine_fault_all_record = machine_fault_all_record_dict[machine_name_i]        # 该机组所有故障记录

            machine_fault_fs_all_record = pd.DataFrame()                                        # 该文件的机组在故障信息表中的所有附属部件故障记录
            if machine_name_i not in fault_machines_fs:
                pass
            else:
                machine_fault_fs_all_record = machine_fault_fs_all_record_dict[machine_name_i]  # 该机组附属部件故障记录
    
            if machine_fault_all_record.empty:                                                  # 如果故障记录为空，说明该机组没有发生过故障
                if data_low.empty:
                    pass
                else:
                    if use_start:                                                                   # 如果为True,说明以数据的开始时间取取一定时间的数据标记为正常机组
                        data_low['Time_Interval'] = data_low[time_column]-machine_start_time
                    else:
                        data_low['Time_Interval'] = machine_end_time-data_low[time_column]          # 计算数据开始时间与机组参数时间的间隔
        
                    data_low['Time_Interval_hour'] = (data_low['Time_Interval'].dt.days*3600*24+data_low['Time_Interval'].dt.seconds)/3600             # 将数据间隔从秒转化为小时
                    normal_data = data_low.loc[(data_low['Time_Interval_hour']<=data_all_days*24) & (data_low['Time_Interval_hour']>=0),filter_cols]   # ????获取正常机组的参数数据（抽取正常机组前60天的数据到建模数据中）
                    # normal_data = data_low.loc[(data_low['Time_Interval_hour']>=0),filter_cols]                                                      # 获取正常机组的参数数据（抽取正常机组前所有的数据到建模数据中）
        
                    if normal_data.empty:
                        pass
                    else:
                        normal_data['FAULT_TYPE']='正常'                                             # 进行正常机组的标记
                        normal_data['TARGET_MARK'] = '0'                                             # 是否故障
                        machine_DFList.append(normal_data)                      
                #————————————————————————————————————————-——————————————
            else: # 如果故障记录不为空，说明发生过附属部件故障+非附属部件故障
                machine_fault_mintime = machine_fault_all_record[fault_starttime_column].min()   # 计算该机组发生故障的最早故障记录
                if data_low.empty:
                    pass
                else:    
                    data_low['Time_Interval_mintime'] = machine_fault_mintime-data_low[time_column]          # 计算故障记录与机组参数时间的间隔
                    data_low['Time_Interval_mintime_hour'] = (data_low['Time_Interval_mintime'].dt.days*3600*24+data_low['Time_Interval_mintime'].dt.seconds)/3600 # 将时间间隔转化为小时
        
                    normal_data = data_low.loc[(data_low['Time_Interval_mintime_hour']>=normal_startday*24)&(data_low['Time_Interval_mintime_hour']<=normal_endday*24),filter_cols]
                    # 将该机组最早故障记录（附属+非附属）时刻之前3-6个月的数据标记为正常数据
        
                    if normal_data.empty:
                        pass
                    else:
                        normal_data['FAULT_TYPE']='正常'                                             # 进行正常机组的标记
                        normal_data['TARGET_MARK'] = '0'                                             # 是否故障
                        machine_DFList.append(normal_data)
                #——————————————————————————————————————————————
    
                if machine_fault_fs_all_record.empty:
                    pass
                else:
                    machine_fault_fs_all_record = machine_fault_fs_all_record.sort_values(by=fault_starttime_column)    # ????该机组全部附属故障记录数据按“故障开始时间”排序    machine_fault_fs_all_record.sort_values(by=fault_starttime_column,inplace=True)                     

                    fault_machine_fs_type = machine_fault_fs_all_record[fault_reason_column].tolist()                   # 获取该机组全部附属部件的故障类型；
                    fault_machine_fs_times = machine_fault_fs_all_record[fault_starttime_column].tolist()               # 获取该机组全部附属部件故障的开始时间
                    machine_fault_fs_all_record['Time_Interval_Fault_type'] = machine_fault_fs_all_record.groupby(
                            [fault_type_column,fault_reason_column])[[fault_starttime_column]].diff(1).replace(np.nan,timedelta(0))
                    fault_type_machine_fs_interval = machine_fault_fs_all_record['Time_Interval_Fault_type'].tolist()   # 获取该机组全部附属部件各类型故障的故障间隔（与前面同类型附属故障的时间间隔）

                    # 1、保证每类附属部件故障最早时间点前14天为故障记录
                    # 2、两类故障在时间上“重叠”（两类故障时间间隔小于14天），“重叠”标注
                    if data_high.empty:
                        pass
                    else:   
                        for (i_fault_fs_type, i_fault_fs_times, i_fault_fs_interval) in zip(fault_machine_fs_type, fault_machine_fs_times, fault_type_machine_fs_interval):
                            data_high['Time_Interval'] = i_fault_fs_times-data_high[time_column]                                                   # 计算故障开始时间与参数时间的间隔(i1从故障记录中获取，data运行数据中获取)
                            data_high['Time_Interval_hour'] = (data_high['Time_Interval'].dt.days*3600*24+data_high['Time_Interval'].dt.seconds)/3600   # 将故障间隔从秒转化为小时
                            # 获取机组的故障数据
                            if ((i_fault_fs_interval == timedelta(0)) or (i_fault_fs_interval>=timedelta(fault_days))):                  # ???如果没有上一次的故障间隔，即只发生过一次故障，或者故障间隔大于标记的故障间隔
                                # 则提取本条记录
                                fault_data = data_high.loc[(data_high['Time_Interval_hour']<=fault_days*24)&(data_high['Time_Interval_hour']>=0),filter_cols]
                            
                                if not fault_data.empty:
                                    fault_data['FAULT_TYPE'] = i_fault_fs_type
                                    fault_data['TARGET_MARK'] = '1'                                     # 进行机组的档案数据标记
                                    machine_DFList.append(fault_data)
                                else:
                                    pass
                            else:                                     
                                # 则取放弃该记录(i_fault_fs_interval<fault_days)
                                pass

    data_LY = pd.concat(machine_DFList).reset_index(drop=True)  # 重置索引
    
    # 重新定义故障类型字段
    if data_LY.empty:
        print('>>>>>> 无数据可取！')
        pass
    else:
        # 重新定义故障类型字段
        data_LY['FAULT_TYPE_2CLASS'] = data_LY.apply(getFiled,axis = 1,args=(1,))  
        data_LY['FAULT_TYPE_2CLASS_W'] = data_LY.apply(getFiled,axis = 1,args=(2,))
        data_LY['FAULT_TYPE_2CLASS_S'] = data_LY.apply(getFiled,axis = 1,args=(3,))
        data_LY['FAULT_TYPE_2CLASS_Y'] = data_LY.apply(getFiled,axis = 1,args=(4,))
        data_LY['FAULT_TYPE_3CLASS_W'] = data_LY.apply(getFiled,axis = 1,args=(5,))
        data_LY['FAULT_TYPE_3CLASS_S'] = data_LY.apply(getFiled,axis = 1,args=(6,))
        data_LY['FAULT_TYPE_3CLASS_Y'] = data_LY.apply(getFiled,axis = 1,args=(7,))
        data_LY['FAULT_TYPE_5CLASS'] = data_LY.apply(getFiled,axis = 1,args=(8,))

        list_columns_name = data_LY.columns.tolist()
        list_columns_name_str = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME','TARGET_MARK','TEMGEAOIL_SIGN',
                               'FAULT_TYPE','FAULT_TYPE_2CLASS','FAULT_TYPE_2CLASS_W','FAULT_TYPE_2CLASS_S','FAULT_TYPE_2CLASS_Y',
                               'FAULT_TYPE_3CLASS_W','FAULT_TYPE_3CLASS_S','FAULT_TYPE_3CLASS_Y','FAULT_TYPE_5CLASS']
        list_columns_name_num = list(set(list_columns_name).difference(set(list_columns_name_str)))             # 运行指标列名称：从列表list_columns_name中剔除列表list_columns_name_str
        data_LY = data_LY.loc[data_LY.loc[:,list_columns_name_num].dropna(axis='index', how='all').index]       # 删除行，条件是整行运行指标全为NaN  ++++++++++++++++++++++++++++
        list_columns_name_str.remove('TEMGEAOIL_SIGN')                                                          # 删除列表元素
        data_LY = data_LY.loc[:,list_columns_name_str + sorted(list_columns_name_num)]                          # sorted() 为列表排序

    return data_LY
        
# =============================================================================
# # 数据划分：通过机场、机型划分
# =============================================================================
def fun_prepare_data_train_LV_out(DF_train,UP):  # 通过机场、机型划分
    Machine_version_UP = UP
    temp_list = list()
    if Machine_version_UP == 'T':
       # 按机场、机组型号拆分数据
       for Machine_location_i in range(len(Machine_location_list)):
           Machine_location_name_i = Machine_location_list[Machine_location_i]
           temp_list_1=list()
           temp_list.append(temp_list_1)
           for Machine_version_i in range(len(Machine_version_list)):
               Machine_version_name_i = Machine_version_list[Machine_version_i]
               df_data_LY = DF_train.loc[(DF_train['MACHINE_VERSION']==Machine_version_name_i) & (DF_train['MACHINE_LOCATION']==Machine_location_name_i),]
               temp_list_1.append(df_data_LY)
    else:
        # 按机场、机组型号后四位拆分数据
        for Machine_location_i in range(len(Machine_location_list)):                                # 循环机场
            Machine_location_name_i = Machine_location_list[Machine_location_i]                     # 赋机场名
            temp_list_1=list()
            temp_list.append(temp_list_1)
            for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):                     # 循环风机型号后4位数
                Machine_version_name_i = list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]     # 赋编机型后四位号名
                df_data_LY = DF_train.loc[(DF_train['MACHINE_VERSION'].apply(lambda x: x.split('-')[1])==Machine_version_name_i) & (DF_train['MACHINE_LOCATION']==Machine_location_name_i),] # 截取后同机场，且机型的后四位数相同
                temp_list_1.append(df_data_LY) 
    
    return temp_list


# =============================================================================
# 数据划分：通过机型划分
# =============================================================================
def fun_prepare_data_train_V_out(DF_train,UP): # 通过机型划分
    Machine_version_UP = UP
    temp_list = list()
    if Machine_version_UP == 'T':
       # 按机组型号拆分数据
       temp_list=list()
       for Machine_version_i in range(len(Machine_version_list)):
           Machine_version_name_i = Machine_version_list[Machine_version_i]
           df_data_LY = DF_train.loc[(DF_train['MACHINE_VERSION']==Machine_version_name_i),]
           temp_list.append(df_data_LY)
    else:
        # 按机组型号后四位拆分数据
        temp_list=list()
        for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):                     # 循环风机型号后4位数
            Machine_version_name_i = list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]     # 赋编机型后四位号名
            df_data_LY = DF_train.loc[(DF_train['MACHINE_VERSION'].apply(lambda x: x.split('-')[1])==Machine_version_name_i),] # 截取后同机场，且机型的后四位数相同
            temp_list.append(df_data_LY) 
    
    return temp_list


# =============================================================================
# 调用函数：读取数据、标注故障类型、实现数据划分、并输出
# =============================================================================
def fun_get_prepare_data_train(param_prepare):  # 保存建模数据
    print("\n============开始运行参数数据读取，并为其标注故障类型，构建模型训练集============")
    DF_train = fun_prepare_data_train(**param_prepare) 
    
    if DF_train.empty:
       print('>>>>>> 无数据保存！')
    else:    
       DF_train.to_csv(temp_train_path +'all_Data_DF_xy.csv',index=False, encoding='utf_8_sig')
    print("=====================结束待建模数据读取=====================\n")

    print("\n=====================开始待分析数据划分=====================")
    print(">>>>>> 数据保存,请稍后...")    
    for Machine_location_TF in ['T','F']:
        for Machine_version_UP in ['T','F']:
            if Machine_location_TF == 'T':  # Machine_location_TF == 'T' 表示同机场、同机型
                DFList_list = fun_prepare_data_train_LV_out(DF_train, Machine_version_UP)
                if Machine_version_UP == 'T':
                   # 按机场、机组型号拆分数据
                   # ----------------------------------------------------------------
                   if isinstance(DFList_list,list):  # 来判断一个对象是否是一个已知的类型
                      for Machine_location_i in  range(len(Machine_location_list)):
                          for Machine_version_i in  range(len(Machine_version_list)):
                              if DFList_list[Machine_location_i][Machine_version_i].empty:
                                 print(Machine_location_list[Machine_location_i]+'_'+Machine_version_list[Machine_version_i],': 无数据输出！')
                                 continue
                              else:
                                 DFList_list[Machine_location_i][Machine_version_i].to_csv(temp_train_path +'['+Machine_location_list[Machine_location_i]+'_'+
                                              Machine_version_list[Machine_version_i]+']_Data_DF_xy.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机场、同机型（带UP）的数据输出！')
                # -----------------------------------------------------------------------------------------------------------------------------------
                else:
                   # 按机场、机组型号后四位输出数据
                   # ----------------------------------------------------------------        
                   if isinstance(DFList_list,list): # 来判断一个对象是否是一个已知的类型
                      for Machine_location_i in range(len(Machine_location_list)):
                          for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):
                              if DFList_list[Machine_location_i][Machine_version_i].empty:
                                 print(Machine_location_list[Machine_location_i]+'_'+list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i],': 无数据输出！')
                                 continue
                              else:
                                 DFList_list[Machine_location_i][Machine_version_i].to_csv(temp_train_path +'['+Machine_location_list[Machine_location_i]+'_'+
                                               list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]+']_Data_DF_xy.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机场、同机型（不带UP）的数据输出！')
            # -----------------------------------------------------------------------------------------------------------------------------------
                
            else : # Machine_location_TF == 'F' 表示不同机场、同机型
                DFList_list = fun_prepare_data_train_V_out(DF_train, Machine_version_UP)
                if Machine_version_UP == 'T':
                   # 按机场、机组型号拆分数据
                   # ----------------------------------------------------------------
                   if isinstance(DFList_list,list):  # 来判断一个对象是否是一个已知的类型
                      for Machine_version_i in  range(len(Machine_version_list)):
                          if DFList_list[Machine_version_i].empty:
                             print(Machine_version_list[Machine_version_i],': 无数据输出！')
                             continue
                          else:
                             DFList_list[Machine_version_i].to_csv(temp_train_path +'['+
                                        Machine_version_list[Machine_version_i]+']_Data_DF_xy.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机型（带UP）的数据输出！')
                # -----------------------------------------------------------------------------------------------------------------------------------
                else:
                   # 按机场、机组型号后四位输出数据
                   # ----------------------------------------------------------------        
                   if isinstance(DFList_list,list): # 来判断一个对象是否是一个已知的类型
                      for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):
                          if DFList_list[Machine_version_i].empty:   
                             print(list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i],': 无数据输出！')
                             continue
                          else:
                             DFList_list[Machine_version_i].to_csv(temp_train_path +'['+
                                           list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]+']_Data_DF_xy.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机型（不带UP）的数据输出！')
            # -----------------------------------------------------------------------------------------------------------------------------------
    print("=====================结束待分析数据划分=====================\n")
    
    
# 主程序
if __name__=='__main__':
    param_prepare = param_prepare_train
    fun_get_prepare_data_train(param_prepare)