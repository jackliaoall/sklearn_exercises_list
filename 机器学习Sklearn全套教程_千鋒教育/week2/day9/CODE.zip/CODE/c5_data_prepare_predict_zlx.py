# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 09:01:14 2019

@author: lenovo
"""

from c0_import_zlx import *
from c0_config_zlx import *
from c0_create_dir import *
from c6_predict_model_apply_zlx import *
from c7_fault_early_warning_zlx import *


# =============================================================================
# temp_test_off_path = '\\数据管理\\预处理好的数据\\离线测试数据\\'
# temp_test_off_path = mkdir(out_path + temp_test_off_path + new_predict_off_dir)+'\\'
# =============================================================================


# =============================================================================
# # 连接数据库，获取分组字段列表
# =============================================================================
def fun_get_group_fields_from_oracle(table_name,field_name_sign = 0):                            # 获取分组字段
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                # 连接数据库
    if field_name_sign == 0:
        str_sql_1 = "select distinct t.machine_name \
                     from "+table_name+" t \
                     order by t.machine_name"                                                    # 获取“机组名称”                                             
        group_fields = pd.read_sql(str_sql_1,conn)
    elif field_name_sign == 1:
        str_sql_2 = "select distinct t.machine_location,t.machine_version \
                     from "+table_name+" t \
                     order by t.machine_name"                                                    # 获取“机场+机组型号”
        group_fields = pd.read_sql(str_sql_2,conn)
    else:
        print('请正确输入参数field_name_sign的值:\n \
              >>>field_name_sign = 0:表示输出“机组”名称;\n \
              >>>field_name_sign = 1:表示输出“机场+机组型号”名称;\n')
        sys.exit(0)                                                                              # 正常退出程序
    conn.close()                                                                                 # 关闭连接   
    return group_fields

# =============================================================================
# # 连接数据库，获取某机组数据
# =============================================================================
def fun_get_data_unit_from_oracle(machine_name,table_name):                                      # 获取单机组数据
    str='user_longyuan/longyuan@localhost:1521/orcl'
    conn = cx_Oracle.connect(str)                                                                # 连接数据库
    str_sql = "select * from "+ table_name +" t  \
               where t.machine_name = '"+ machine_name +"' \
               order by t.machine_name,t.LocalTime"                                              # 测试集提取
    data_unit_df = pd.read_sql(str_sql,conn)
    conn.close()                                                                                 # 关闭连接
    return data_unit_df

# =============================================================================
# # 获取测试数据
# =============================================================================
def fun_get_prepare_data_predict(ora_table_name,time_column):
    machine_name_DF = fun_get_group_fields_from_oracle(ora_table_name,field_name_sign = 0)      # 获取客户数据的机组名数据框 
    machine_name_list = machine_name_DF['MACHINE_NAME'].tolist()                                # 将数据框转换为机组名列表
    machine_DFList = [] 
    for machine_name_i in tqdm(machine_name_list, desc='>>>>>> 处理进度', unit='files'):         # 用tqdm模块实现进度条显示
        data_x = fun_get_data_unit_from_oracle(machine_name_i,ora_table_name)                   # 连接数据库，获取某机组数据
        data_x[time_column] = pd.to_datetime(data_x[time_column],errors='coerce')               # 日期类型转化
        data_columns_list = ['MACHINE_NAME','MACHINE_VERSION','MACHINE_LOCATION','LOCALTIME','TEMGEAOIL_SIGN']
        data_x = data_x.loc[data_x.iloc[:,len(data_columns_list):].dropna(axis='index', how='all').index]       # 删除行，条件是整行的运行参数均为NaN
        feature_columns_list = list(set(data_x.columns.tolist()) - set(data_columns_list))                       # 特征字段名列表
        feature_columns_list.sort()                                                                                 # 特征字段名列表排序
        data_columns_list.remove('TEMGEAOIL_SIGN')                                                                    # 删除列表元素
        new_columns_name_list = data_columns_list + feature_columns_list                                               # 整理字段名列表，将特征字段名排序
        data_x = data_x[new_columns_name_list]                                                          # 整理字段顺序后的数据框
        data_x = data_x.sort_values(by = ['MACHINE_NAME','LOCALTIME'])
        machine_DFList.append(data_x)
    data_LY = pd.concat(machine_DFList).reset_index(drop=True)
    return data_LY

# -----------------------------------------------------------------------------    machine_name_list.remove('TEMGEAOIL_SIGN')
        
def fun_prepare_data_predict_LV_out(DF_predict, UP):  # 通过机场、机型划分
    Machine_version_UP = UP
    temp_list = list()
    if Machine_version_UP == 'T':
       # 按机场、机组型号拆分数据
       for Machine_location_i in range(len(Machine_location_list)):
           Machine_location_name_i = Machine_location_list[Machine_location_i]
           temp_list_1=list()
           temp_list.append(temp_list_1)
           for Machine_version_i in range(len(Machine_version_list)):
               Machine_version_name_i = Machine_version_list[Machine_version_i]
               df_data_LY = DF_predict.loc[(DF_predict['MACHINE_VERSION']==Machine_version_name_i) & (DF_predict['MACHINE_LOCATION']==Machine_location_name_i),]
               temp_list_1.append(df_data_LY)
    else:
        # 按机场、机组型号后四位拆分数据
        for Machine_location_i in range(len(Machine_location_list)):                                # 循环机场
            Machine_location_name_i = Machine_location_list[Machine_location_i]                     # 赋机场名
            temp_list_1=list()
            temp_list.append(temp_list_1)
            for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):                     # 循环风机型号后4位数
                Machine_version_name_i = list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]     # 赋编机型后四位号名
                df_data_LY = DF_predict.loc[(DF_predict['MACHINE_VERSION'].apply(lambda x: x.split('-')[1])==Machine_version_name_i) & (DF_predict['MACHINE_LOCATION']==Machine_location_name_i),] # 截取后同机场，且机型的后四位数相同
                temp_list_1.append(df_data_LY) 
    
    return temp_list

# -----------------------------------------------------------------------------
def fun_prepare_data_predict_V_out(DF_predict,UP): # 通过机型划分
    Machine_version_UP = UP
    temp_list = list()
    if Machine_version_UP == 'T':
       # 按机组型号拆分数据
       temp_list=list()
       for Machine_version_i in range(len(Machine_version_list)):
           Machine_version_name_i = Machine_version_list[Machine_version_i]
           df_data_LY = DF_predict.loc[(DF_predict['MACHINE_VERSION']==Machine_version_name_i),]
           temp_list.append(df_data_LY)
    else:
        # 按机组型号后四位拆分数据
        temp_list=list()
        for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):                     # 循环风机型号后4位数
            Machine_version_name_i = list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]     # 赋编机型后四位号名
            df_data_LY = DF_predict.loc[(DF_predict['MACHINE_VERSION'].apply(lambda x: x.split('-')[1])==Machine_version_name_i),] # 截取后同机场，且机型的后四位数相同
            temp_list.append(df_data_LY) 
    
    return temp_list

# =============================================================================
# # =====================================离线==================================
# =============================================================================
               
def fun_get_prepare_data_predict_off(DF_predict):  # 保存离线数据
    print("\n=====================开始待分析数据划分=====================")
    print(">>>>>> 数据保存,请稍后...")    
    for Machine_location_TF in ['T','F']:
        for Machine_version_UP in ['T','F']:
            if Machine_location_TF == 'T':  # Machine_location_TF == 'T' 表示同机场、同机型
                DFList_list = fun_prepare_data_predict_LV_out(DF_predict, Machine_version_UP)
                if Machine_version_UP == 'T':
                   # 按机场、机组型号拆分数据
                   # ----------------------------------------------------------------
                   if isinstance(DFList_list,list):  # 来判断一个对象是否是一个已知的类型
                      for Machine_location_i in  range(len(Machine_location_list)):
                          for Machine_version_i in  range(len(Machine_version_list)):
                              if DFList_list[Machine_location_i][Machine_version_i].empty:
                                 print(Machine_location_list[Machine_location_i]+'_'+Machine_version_list[Machine_version_i],': 无数据输出！')
                                 continue
                              else:
                                 DFList_list[Machine_location_i][Machine_version_i].to_csv(temp_test_off_path + '['+Machine_location_list[Machine_location_i]+'_'+
                                              Machine_version_list[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机场、同机型（带UP）的数据输出！')
                # -----------------------------------------------------------------------------------------------------------------------------------
                else:
                   # 按机场、机组型号后四位输出数据
                   # ----------------------------------------------------------------        
                   if isinstance(DFList_list,list): # 来判断一个对象是否是一个已知的类型
                      for Machine_location_i in range(len(Machine_location_list)):
                          for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):
                              if DFList_list[Machine_location_i][Machine_version_i].empty:
                                 print(Machine_location_list[Machine_location_i]+'_'+list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i],': 无数据输出！')
                                 continue
                              else:
                                 DFList_list[Machine_location_i][Machine_version_i].to_csv(temp_test_off_path + '['+Machine_location_list[Machine_location_i]+'_'+
                                               list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机场、同机型（不带UP）的数据输出！')
            # -----------------------------------------------------------------------------------------------------------------------------------
                
            else :  # Machine_location_TF == 'F' 表示不同机场、同机型
                DFList_list = fun_prepare_data_predict_V_out(DF_predict, Machine_version_UP)
                if Machine_version_UP == 'T':
                   # 按机场、机组型号拆分数据
                   # ----------------------------------------------------------------
                   if isinstance(DFList_list,list):  # 来判断一个对象是否是一个已知的类型
                      for Machine_version_i in  range(len(Machine_version_list)):
                          if DFList_list[Machine_version_i].empty:
                             print(Machine_version_list[Machine_version_i],': 无数据输出！')
                             continue
                          else:
                             DFList_list[Machine_version_i].to_csv(temp_test_off_path + '['+
                                        Machine_version_list[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机型（带UP）的数据输出！')
                # -----------------------------------------------------------------------------------------------------------------------------------
                else:
                   # 按机场、机组型号后四位输出数据
                   # ----------------------------------------------------------------        
                   if isinstance(DFList_list,list): # 来判断一个对象是否是一个已知的类型
                      for Machine_version_i in range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):
                          if DFList_list[Machine_version_i].empty:   
                             print(list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i],': 无数据输出！')
                             continue
                          else:
                             DFList_list[Machine_version_i].to_csv(temp_test_off_path + '['+
                                           list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
                   else:
                      print('>>>>>> 无同机型（不带UP）的数据输出！')
            # -----------------------------------------------------------------------------------------------------------------------------------
    print("\n=====================结束待分析数据划分=====================")
    
# -----------------------------------------------------------------------------

def fun_get_prepare_data_predict_offline(param_prepare):
    print("\n=====================开始待建模数据读取=====================") 
    DF_predict = fun_get_prepare_data_predict(**param_prepare) 
    
    if DF_predict.empty:
       print('>>>>>> 无数据保存！')
    else:    
       DF_predict.to_csv(temp_test_off_path + 'all_Data_DF_x.csv',index=False, encoding='utf_8_sig')
    print("\n=====================结束待建模数据读取=====================")
    
    fun_get_prepare_data_predict_off(DF_predict)    # 保存离线拆分的数据
    data_list = fun_data_processing_predict()       # 离线数据预处理
    Y_model_data = fun_apply_model(data_list[0],temp_out_off_path)       # 进行模型调用，预测故障 
    df_temp_early_warning = fun_fault_early_warning(Y_model_data,'预测',temp_out_off_path)    # 输出最终报警成果
    # 通过df_temp_early_warning返回的机组名、时间标记，用数据data_list[1]绘图
    for (machine_name_i,fault_yc_i,localtime_i) in zip(df_temp_early_warning['MACHINE_NAME'].tolist(),df_temp_early_warning['Fault_yc'].tolist(),df_temp_early_warning['LOCALTIME'].tolist()):
        data_fault = data_list[1].loc[data_list[1]['MACHINE_NAME']==machine_name_i,].sort_values(by= ['MACHINE_NAME','LOCALTIME'])
        fun_data_plot(data_fault,machine_name_i,fault_yc_i,localtime_i,temp_out_off_plot_path)
    
           
# =============================================================================
# # =======================================在线================================
# =============================================================================

def fun_get_prepare_data_predict_on(DFList_list):   # 保存在线数据，并处理数据，进行模型调用，输出最终报警成果
    print("\n=====================开始待分析数据划分=====================")
    print(">>>>>> 待分析数据划分中，请稍后...")
    time_now = time.time()                          # 返回当前时间的时间戳
    if Machine_version_UP:
       # 按机场、机组型号拆分数据
       if isinstance(DFList_list,list):             # 判断“DFList_list”是否为列表
          for Machine_location_i in  range(len(Machine_location_list)):
              for Machine_version_i in  range(len(Machine_version_list)):
                  if DFList_list[Machine_location_i][Machine_version_i].empty:
                     print(Machine_location_list[Machine_location_i]+'_'+Machine_version_list[Machine_version_i],': 无数据输出！')
                  else:
                     data_temp = DFList_list[Machine_location_i][Machine_version_i]
                     data_temp.loc[(data_temp['LocalTime']<= time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time_now-1*2592000))) & 
                                   (data_temp['LocalTime']>= time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time_now-2*2592000))),].to_csv(out_path +
                                    temp_test_off_path + '['+Machine_location_list[Machine_location_i]+'_'+
                                     Machine_version_list[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
       else:
           print('>>>>>> 无数据输出！')
    else:
       # 按机场、机组型号后四位输出数据
       if isinstance(DFList_list,list):
           for Machine_location_i in  range(len(Machine_location_list)):
               for Machine_version_i in  range(len(set([x_i.split('-')[1] for x_i in Machine_version_list]))):
                   if DFList_list[Machine_location_i][Machine_version_i].empty:  
                      print(Machine_location_list[Machine_location_i]+'_'+list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i],': 无数据输出！')
                   else:
                      data_temp = DFList_list[Machine_location_i][Machine_version_i] 
                      data_temp.loc[(data_temp['LocalTime']<= time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time_now-1*2592000))) & 
                                    (data_temp['LocalTime']>= time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time_now-2*2592000))),].to_csv(out_path +
                                     temp_test_off_path + '['+Machine_location_list[Machine_location_i]+'_'+
                                    list(set([x_i.split('-')[1] for x_i in Machine_version_list]))[Machine_version_i]+']_Data_DF_x.csv',index=False,encoding='utf_8_sig')
       else:
           print('>>>>>> 无数据输出！')
    print("\n=====================结束待分析数据划分=====================")

    data_list = fun_data_processing_predict()       # 离线数据预处理
    Y_model_data = fun_apply_model(data_list[0],temp_out_on_path)       # 进行模型调用，预测故障 
    df_temp_early_warning = fun_fault_early_warning(Y_model_data,'预测',temp_out_on_path)    # 输出最终报警成果
    # 通过df_temp_early_warning返回的机组名、时间标记，用数据data_list[1]绘图
    for (machine_name_i,fault_yc_i,localtime_i) in zip(df_temp_early_warning['MACHINE_NAME'].tolist(),df_temp_early_warning['Fault_yc'].tolist(),df_temp_early_warning['LOCALTIME'].tolist()):
        data_fault = data_list[1].loc[data_list[1]['MACHINE_NAME']==machine_name_i,].sort_values(by= ['MACHINE_NAME','LOCALTIME'])
        fun_data_plot(data_fault,machine_name_i,fault_yc_i,localtime_i,temp_out_on_plot_path)

# -----------------------------------------------------------------------------

def fun_trigger_online(DFList_list):                # 定时触发，调用函数fun_get_prepare_data_predict_on
    scheduler = BlockingScheduler()                 # 调度器模块
    scheduler.add_job(fun_get_prepare_data_predict_on, 'interval', minutes=1, args=[DFList_list])  # 添加一个作业 fun_get_prepare_data_predict_on，触发器为 interval，每隔 1分钟执行一次
    print('>>>>>> Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        pass    

# -----------------------------------------------------------------------------

# =============================================================================
# def fun_get_prepare_data_predict_online(param_prepare):
#     print("\n=====================开始待分析数据读取=====================")
#     DF_predict = fun_get_prepare_data_predict(**param_prepare)
#     DFList_list = []
#     if Machine_location:
#         DFList_list = fun_prepare_data_predict_LV_out(DF_predict)
#         print("\n=====================结束待分析数据读取=====================")
#     else:
#         DFList_list = fun_prepare_data_predict_V_out(DF_predict)
#         print("\n=====================结束待分析数据读取=====================")
#     fun_trigger_online(DFList_list)
# =============================================================================

# 在线一定是某一台机组，这台机组的风场、机型都定死了，所以不需要拆分数据
def fun_get_prepare_data_predict_online(param_prepare):
    print("\n=====================开始待分析数据读取=====================")
    DF_predict = fun_get_prepare_data_predict(**param_prepare)
    fun_trigger_online(DF_predict)

# =============================================================================


# 主程序
if __name__=='__main__':
    param_prepare_off = param_prepare_predict_off
    #param_prepare_on = param_prepare_predict_on
    fun_get_prepare_data_predict_offline(param_prepare_off)
    #fun_get_prepare_data_predict_online(param_prepare_on)