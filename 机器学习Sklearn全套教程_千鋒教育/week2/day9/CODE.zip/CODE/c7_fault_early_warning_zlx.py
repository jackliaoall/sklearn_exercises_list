# -*- coding: utf-8 -*-
"""
Created on Sun Jun 30 05:12:44 2019

@author: lenovo
"""

from c0_import_zlx import *
from c0_config_zlx import *


######################### 转换为客户需要的输出成果 #############################
def fun_fault_early_warning(data_x,code_name,warning_out_path):
    print("\n>>>>>>>>>>>>>>>>>>>  故障预警中...  <<<<<<<<<<<<<<<<<<<<\n")
    data = data_x
    data['fault_Boolean'] = data['Fault_yc'].apply(lambda x: -1 if x=='正常' else 1)                                    # 将正常设为-1，其他设为1
    data['LOCALTIME'] = pd.to_datetime(data['LOCALTIME'],format='%Y/%m/%d %H:%M:%S')                                    # 时间类型转换
    data_yc = data.sort_values(by=['MACHINE_NAME','Fault_yc','LOCALTIME']).reset_index(drop = True)                     # 为数据排序
    data_yc.index = data_yc['LOCALTIME']                                                                                # 将时间定义为索引
    df_2days_rolling = data_yc.groupby(['MACHINE_NAME','Fault_yc'],as_index=True)['fault_Boolean'].rolling(str(int(1*24*3600))+'s').sum().reset_index()  # 移动窗口设置。  reset_index() :将Series的复合索引提取为列 ；
    df_2days_rolling['fault_Boolean'] = df_2days_rolling['fault_Boolean'].apply(lambda x: 0 if x<1*144*0.8 else 1)      # 设置阀值，重新标注故障点;(1:故障发生频繁时间段，0：故障发生不频繁时间段)
    df_2days_rolling_out = df_2days_rolling.loc[df_2days_rolling['fault_Boolean']==1,].sort_values(by=['MACHINE_NAME','Fault_yc','LOCALTIME']).reset_index(drop = True)     # 挑出故障数据，并分组排序

    if df_2days_rolling_out.empty:
        print("\n>>>>>>>>>>>>>>>>>>>  没有在【"+code_name+"】数据中找到可预警的故障机组！ <<<<<<<<<<<<<<<<<<<<\n")
        pass
    else:
        print("\n>>>>>>>>>>>>>>>>>>>  结果数据目录："+warning_out_path+"  <<<<<<<<<<<<<<<<<<<<\n")
        df_2days_rolling_out['Fault_time_interval'] = df_2days_rolling_out.groupby(['MACHINE_NAME','Fault_yc'])['LOCALTIME'].diff(-1).replace(np.nan,timedelta(0))  # replace() 方法把字符串中的空值（nan）替换成时长为0
        df_2days_rolling_out = df_2days_rolling_out.loc[(abs(df_2days_rolling_out['Fault_time_interval']) > timedelta(days = 30))|(df_2days_rolling_out['Fault_time_interval'] == timedelta(0)),]  # 提取同机组、同故障中的第一条预测故障和与前一条预测故障的间隔超过30天的第一条预测故障记录
        df_rolling_out = df_2days_rolling_out.rename(columns={'MACHINE_NAME':'机组名称', 'Fault_yc':'故障类型','LOCALTIME':'报警时间'})       # 更换表头
        str_datetime = time.strftime('%Y-%m-%d_%H-%M-%S',time.localtime(time.time()))                                   # 设定输出文件时刻
        df_rolling_out[['机组名称','故障类型','报警时间']].to_csv(warning_out_path +'\\'+code_name+'_成果_('+str_datetime+').csv', index=False, encoding='utf_8_sig')
        print(df_rolling_out[['机组名称','故障类型','报警时间']])
    return df_2days_rolling_out[['MACHINE_NAME','Fault_yc','LOCALTIME']]  # 返回结果的机组、时间


######################### 采用故障机组最近一个月的数据绘制时序图 #############################
def fun_data_plot(fault_data,machine_name_i,i_fault_fs_type,i_fault_fs_times,plot_path):
    fault_data['LOCALTIME'] = pd.to_datetime(fault_data['LOCALTIME'],format='%Y-%m-%d %H:%M:%S')
    #i_fault_fs_times = datetime.datetime.strptime(i_fault_fs_times,'%Y-%m-%d %H:%M:%S')
    fault_data = fault_data.loc[(fault_data['LOCALTIME']<=i_fault_fs_times)&(fault_data['LOCALTIME']>=(i_fault_fs_times-timedelta(days = 30))),]
    parameter_name_list = ['GENACTIVEPW_AVG','ROTORSPD_AVG','TEMGEAMSDE_AVG','TEMGEAOIL_AVG','TEMOUT_AVG','WINDSPEED_AVG']
    parameter_name_num = len(parameter_name_list)
    fig=plt.figure(figsize=(30,24))                 # 调整画图空间的大小
    date_format=mpl.dates.DateFormatter('%Y-%m-%d') # 设定显示的格式形式
    for (parameter_name_i,i) in zip(parameter_name_list,range(1,parameter_name_num+1)):
        dates_v = fault_data['LOCALTIME']                                                   # 时间值
        values_v = fault_data[parameter_name_i]                                             # 参数值
        fault_name_i = i_fault_fs_type                                                      # 故障类型
        fault_fs_times_i = i_fault_fs_times.strftime("%Y-%m-%d_%H-%M-%S")                   # 故障时间点(转化为字符串)
        if  (False in values_v.isna().tolist()) and (values_v.count()>1):                   # 判断values_v是否全为nan值，如果不是就绘图 ;且非空数据大于1个                                       
            ax=fig.add_subplot(parameter_name_num,1,i)      # plt.gca()获得当前的Axes对象ax，然后再调用ax.plot()方法实现真正的绘图
            ax.xaxis.set_major_formatter(date_format)       # 设定x轴主要格式
            ax.xaxis.set_major_locator(mpl.ticker.MultipleLocator(1))#设定坐标轴的显示的刻度间隔
            ax.plot(dates_v,values_v,linestyle='-',marker='.',c='b',alpha=0.5) # 作图
            fig.autofmt_xdate()                             # 防止x轴上的数据重叠，自动调整。
            plt.rcParams['font.sans-serif'] = ['SimHei']    # 中文字体设置plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文字体设置
            plt.title('时间序列图 【'+machine_name_i+';'+fault_name_i+';'+fault_fs_times_i+';'+parameter_name_i+'】')
            plt.xlabel('时间【故障时间点：'+fault_fs_times_i+'】')
            plt.ylabel('运行参数：'+parameter_name_i)            
            print("绘图数据量数据量：%d;绘图天数：%d"%(fault_data.shape[0],fault_data.shape[0]/144))          # 测试
        else:
            print('该列为空值！')
    plt.savefig(plot_path +'\\'+ machine_name_i+'_'+i_fault_fs_type+'_'+i_fault_fs_times.strftime("%Y-%m-%d_%H-%M-%S")+'.jpg', dpi=300)
    plt.show()
        