# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 21:13:13 2019

@author: lenovo
"""
from c0_config_zlx import *
from c0_create_dir import *
from c1_to_oracle_data_prepare_zlx import *
from c2_to_oracle_data_prepare_agg_zlx import *
from c3_data_prepare_train_zlx import *
from c4_train_model_create_zlx import *
from c5_data_prepare_predict_zlx import *
from c6_predict_model_apply_zlx import *
import argparse


if __name__ == '__main__':
    print('模型命令：python main.py --order "命令" \n【"可输入命令"：train-训练模型，predict_offline-离线测试模型，predict_online-在线测试模型】')
    parser = argparse.ArgumentParser()                                                                                  # 创建解析器对象ArgumentParser
    parser.description='模型命令：train-训练模型，predict_offline-离线测试模型，predict_online-在线测试模型'            # 为对象ArgumentParser添加参数
    parser.add_argument('--order', default='order', type=str)                                                           # 用来指定程序需要接受的命令参数
    args = parser.parse_args()                                                                                          # 从命令行参数中返回了一些数据
    if args.order=='train':
        print('导入训练数据，请等待...')
        fun_to_Oracle_all(**param_prepare_create_train)
        print('对训练数据进行聚合运算，请等待...')
        fun_data_agg_to_oracel(**param_prepare_agg_train)
        print('对训练数据进行故障标记，请等待...')
        param_prepare = param_prepare_train
        fun_get_prepare_data_train(param_prepare)                               # 获取标记好故障的训练数据  
        print('模型重训练：正在构建故障机组识别模型，请等待...')
        fun_train_model_apply()                                                 # 训练模型，并检验模型
    elif args.order=='predict_offline':
        print('导入离线数据，请等待...')
        fun_to_Oracle_all(**param_prepare_create_predict_off)
        print('对离线数据进行聚合运算，请等待...')
        fun_data_agg_to_oracel(**param_prepare_agg_predict_off)
        print('离线数据预警：正在调用模型对离线数据进行故障识别，请等待...')
        param_prepare_off = param_prepare_predict_off
        fun_get_prepare_data_predict_offline(param_prepare_off)                 # 获取离线测试数据
    elif args.order=='predict_online':
        print('导入在线数据，请等待...')
        fun_to_Oracle_all(**param_prepare_create_predict_on)
        print('对在线数据进行聚合运算，请等待...')
        fun_data_agg_to_oracel(**param_prepare_agg_predict_on)
        print('在线数据预警：正在调用模型对离线数据进行故障识别，请等待...')
        param_prepare_on = param_prepare_predict_on
        fun_get_prepare_data_predict_online(param_prepare_on)                   # 在线预测
    else:
        print('请输入正确参数')