# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 09:43:02 2019

@author: lenovo
"""
from c0_import_zlx import *

##################### 获取所有压缩文件中所有文件的路径 ########################
def getListZips(path):        # 获取文件名
    ret = [] 
    for root, dirs, files in os.walk(path):  # 用于通过在目录树中游走输出在目录中的文件名 
        for filespath in files: 
            ret.append(os.path.join(root,filespath))
    return ret

####################获取文件路径中的风机场名称######################
def get_machine_loaction(machine_locations,pathname):          # 获取机场名称
    for i in machine_locations:
        if i in pathname:
            return i
            break
        
#################### 获取文件路径中的风机ID ###########################
def get_machine_id(pathname):
    if '#' in pathname:
        file_name=pathname.split('#')[-1]    # 获取'#'最后一个分段字符串
        machine_id=file_name.split('.')[0]   # 获取'.'第一个分段字符串
        return str(int(machine_id))
    elif '_' in pathname and '麒麟山' in pathname:  # 特殊处理麒麟山
        file_name=pathname.split('_')[-1]    # 获取'_'最后一个分段字符串
        machine_id=file_name.split('.')[0]   # 获取'.'第一个分段字符串
        return str(machine_id)
    elif '-' in pathname:
        file_name=pathname.split('-')[-1]   # 获取'-'第一个分段字符串
        machine_id=file_name.split('.')[0]  # 获取'.'第一个分段字符串
        return str(int(machine_id))
    else:
        return None

#################### 对数据进行差分特征提取 ##########################
def data_feature_pre(data):      
    df_diff=data.diff(-1)                   # 差分运算
    for col in data.columns:       
        data[col+'_diff'] = df_diff[col]    # 为差分字段添加字段名
    return data

#################### 获取使用参数的列名 ###############################
# 保证data中的列名是从data_columns中“引申（聚合运算）”而来；如果不是就剔除掉该列名
def data_filter_columns(data,data_columns):  
    filter_columns=[]
    for i in data.columns:
        col=i.split('_')[0]                     # 获取'_'最第一个分段字符串
        if col in data_columns:
            filter_columns.append(i)            # 将列名添加到列表中
        else:
            pass
    return filter_columns 

####################### 列名中文转化为英文 ########################
def column_transform(data,data_columns_map):
    ly_col=[]
    for i in data.columns:
        name = i.split('_')[0]  # 获取中文名称
        name_trans = data_columns_map.get(name) # 从数据列名中英文对照表中获取中文对应的英文名称
        if name_trans:
            ly_col.append(i.replace(name,name_trans).upper())  # 替换名称，并将后缀转换为大写
        else:
            ly_col.append(i.upper())                           # 将后缀转换为大写
    return ly_col

####################### 过滤极端值+填充缺失值 ############################
def detect_outliers(df, features_range):                                # 极端值过滤+缺失值填充
    df['LOCALTIME'] = pd.to_datetime(df['LOCALTIME'], errors='coerce')  # 日期类型转化
    df = df.sort_values(by=['LOCALTIME']).reset_index(drop = True)      # 为数据排序
    df = df.applymap(lambda x: x if (x not in [-902,850]) else np.nan)  # 将值为-902值替换为 nan
# =============================================================================
#     df.loc[(df['齿轮箱油温_avg']>=-4.15) & (df['齿轮箱油温_avg']<=-3.85),['齿轮箱油温_avg']] = np.nan  # 将齿轮箱油压（gearboxdistri）的值
# =============================================================================
    df = df.loc[df.iloc[:,7:].dropna(axis='index', how='all').index]    # 删除表中运行参数全部为NaN的行

    # =====================================参数值过滤===============================
# =============================================================================
#     outlier_indices = []
#     for col,range_value in features_range.items():  # 获取列名称和参数范围
#         if range_value:
#             value_min, value_max = range_value      # 获取参数最大值、最小值
#             if col in df.columns.tolist():
#                outlier_list_col = df[(df[col] < value_min) | (df[col] > value_max)].index  # 过滤不符合条件的索引
#             else:
#                pass
#         else:
#             pass
#         outlier_indices.extend(outlier_list_col)              # 函数用于在列表末尾一次性追加另一个序列中的多个值
#         outlier_indices=list(set(outlier_indices))            # 将不符合条件的行索引去重
#     df = df.drop(outlier_indices).reset_index(drop = True)    # 删除不符合过滤范围的行
# =============================================================================
    
    # =====================================缺失值填充===============================
# =============================================================================
#     df = df.interpolate()                                           # 线性进行线性插补缺漏值  inplace=True
#     df = df.fillna(method='pad')                                    # 用前一个数据代替NaN
#     df = df.fillna(method='bfill')                                  # 用后一个数据代替NaN
# =============================================================================
    
    df = df.loc[df.iloc[:,7:].drop_duplicates().index.tolist(),]      # 对行相同的数据参数去重（可能是假数据）
    df = df.fillna(0)                                                 # 用0填充所有空值
    return df

####################### 创建文件夹 ############################
def mkdir(path):
    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)
        print(path + ' 创建成功')
        return path
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path + ' 目录已存在')
        return path

